<h1>Italy</h1>

https://en.wikipedia.org/wiki/Television_in_Italy#Digital_terrestrial_television
https://www.tivusat.tv/sat-eng/tivusat/multicanale.aspx

<h2>National DVB-T</h2>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | Rai 1         | [>](https://d3k8wzt41aflvx.cloudfront.net/RAI1/Live.m3u8) | <img height="20" src="https://i.imgur.com/CAx7yRm.png"/> | Rai1.it |
| 1   | Rai 1 Ⓖ       | [>](https://mediapolis.rai.it/relinker/relinkerServlet.htm?cont=2606803&output=7&forceUserAgent=rainet/4.0.5) | <img height="20" src="https://i.imgur.com/CAx7yRm.png"/> | Rai1.it |
| 2   | Rai 2         |  [>](https://d3k8wzt41aflvx.cloudfront.net/RAI2/Live.m3u8) | <img height="20" src="https://i.imgur.com/zA0PTcs.png"/> | Rai2.it |
| 2   | Rai 2 Ⓖ       | [>](https://mediapolis.rai.it/relinker/relinkerServlet.htm?cont=308718&output=7&forceUserAgent=rainet/4.0.5) | <img height="20" src="https://i.imgur.com/zA0PTcs.png"/> | Rai2.it |
| 3   | Rai 3         | [>](https://d3k8wzt41aflvx.cloudfront.net/RAI3/Live.m3u8) | <img height="20" src="https://i.imgur.com/9kuQCIi.png"/> | Rai3.it |
| 3   | Rai 3 Ⓖ       | [>](https://mediapolis.rai.it/relinker/relinkerServlet.htm?cont=308709&output=7&forceUserAgent=rainet/4.0.5) | <img height="20" src="https://i.imgur.com/9kuQCIi.png"/> | Rai3.it |
| 4   | Rete 4 Ⓖ      | [>](https://live02-seg.msf.cdn.mediaset.net/live/ch-r4/r4-clr.isml/index.m3u8) | <img height="20" src="https://i.imgur.com/GWx2Fkl.png"/> | Rete.4.it |
| 5   | Canale 5 Ⓖ    | [>](https://live02-seg.msf.cdn.mediaset.net/live/ch-c5/c5-clr.isml/index.m3u8) | <img height="20" src="https://i.imgur.com/p6YdiR1.png"/> | Canale.5.it |
| 6   | Italia 1 Ⓖ    | [>](https://live02-seg.msf.cdn.mediaset.net/live/ch-i1/i1-clr.isml/index.m3u8) | <img height="20" src="https://i.imgur.com/oCiOxBG.png"/> | Italia.1.it |
| 7   | La7            | [>](https://d1chghleocc9sm.cloudfront.net/v1/master/3722c60a815c199d9c0ef36c5b73da68a62b09d1/cc-evfku205gqrtf/Live.m3u8) | <img height="20" src="https://i.imgur.com/F90mpSa.png"/> | LA7.HD.it |
| 8   | TV8 Ⓖ         | [>](https://hlslive-web-gcdn-skycdn-it.akamaized.net/TACT/11223/tv8web/master.m3u8?hdnts=st=1764666351~exp=1829466206~acl=/*~hmac=b0e9165b6c55027903ad103c8219f363d8765eb300c0d9a339e9767fc3509556) | <img height="20" src="https://i.imgur.com/xvoHVOU.png"/> | TV8.HD.it |
| 9   | Nove           | [>](https://streaming.aurora.enhanced.live/live/mpc/enl0eG1mLmVncmVzcy5mZDJ2eHI=/out/v1/IT_SIMULCAST/NOVE/CMAF/index.m3u8) | <img height="20" src="https://i.imgur.com/Hp723RU.png"/> | Nove.it |
| 20  | 20 Mediaset Ⓖ | [>](https://live02-seg.msf.cdn.mediaset.net/live/ch-lb/lb-clr.isml/index.m3u8) | <img height="20" src="https://i.imgur.com/It13jwX.png"/> | 20.it |
| 21  | Rai 4 Ⓖ       | [>](https://mediapolis.rai.it/relinker/relinkerServlet.htm?cont=746966&output=7&forceUserAgent=rainet/4.0.5) | <img height="20" src="https://i.imgur.com/XFkZRfv.png"/> | Rai4.it |
| 22  | Iris Ⓖ     | [>](https://live02-seg.msf.cdn.mediaset.net/live/ch-ki/ki-clr.isml/index.m3u8) | <img height="20" src="https://i.imgur.com/Ixz1BY3.png"/> | Iris.it |
| 23  | Rai 5 Ⓖ       | [>](https://mediapolis.rai.it/relinker/relinkerServlet.htm?cont=395276&output=7&forceUserAgent=rainet/4.0.5) | <img height="20" src="https://i.imgur.com/Leu2zTO.png"/> | Rai5.it |
| 24  | Rai Movie Ⓖ   | [>](https://mediapolis.rai.it/relinker/relinkerServlet.htm?cont=747002&output=7&forceUserAgent=rainet/4.0.5) | <img height="20" src="https://i.imgur.com/RKpO8CE.png"/> | RaiMovie.it |
| 25  | Rai Premium   | [>](https://d3k8wzt41aflvx.cloudfront.net/RaiPremium/Live.m3u8) | <img height="20" src="https://i.imgur.com/RKI4nFy.png"/> | RaiPremium.it |
| 25  | Rai Premium Ⓖ | [>](https://mediapolis.rai.it/relinker/relinkerServlet.htm?cont=746992&output=7&forceUserAgent=rainet/4.0.5) | <img height="20" src="https://i.imgur.com/RKI4nFy.png"/> | RaiPremium.it |
| 26  | Cielo Ⓖ       | [>](https://hlslive-web-gcdn-skycdn-it.akamaized.net/TACT/11219/cieloweb/master.m3u8?hdnts=st=1764666351~exp=1829466206~acl=/*~hmac=b0e9165b6c55027903ad103c8219f363d8765eb300c0d9a339e9767fc3509556) | <img height="20" src="https://i.imgur.com/cPluF03.png"/> | cielo.it |
| 27  | 27 Twentyseven Ⓖ | [>](https://live02-seg.msf.cdn.mediaset.net/live/ch-ts/ts-clr.isml/index.m3u8) | <img height="20" src="https://i.imgur.com/y2PdPCK.png"/> | 27Twentyseven.it |
| 28  | TV 2000        | [>](https://hls-live-tv2000.akamaized.net/hls/live/2028510/tv2000/master.m3u8) | <img height="20" src="https://i.imgur.com/x7RaK3a.png"/> | TV2000.va |
| 29  | La7 Cinema     | [>](https://viamotionhsi.netplus.ch/live/eds/la7d/browser-HLS8/la7d.m3u8) | <img height="20" src="https://i.imgur.com/khPweok.png"/> | LA7.Cinema.it |
| 30  | La 5 Ⓖ     | [>](https://live02-seg.msf.cdn.mediaset.net/live/ch-ka/ka-clr.isml/index.m3u8) | <img height="20" src="https://i.imgur.com/UNyJaho.png"/> | La5.it |
| 31  | Real Time      | [>](https://streaming.aurora.enhanced.live/live/mpc/enl0eG1mLmVncmVzcy5mZDJ2eHI=/out/v1/IT_SIMULCAST/REALTIME/CMAF/index.m3u8) | <img height="20" src="https://i.imgur.com/9dcTYg1.png"/> | Real.Time.it |
| 32  | QVC            | [>](https://qrg.akamaized.net/hls/live/2017383/lsqvc1it/master.m3u8) | <img height="20" src="https://i.imgur.com/Ea7iUX2.png"/> | QVC.it |
| 33  | Food Network   | [>](https://streaming.aurora.enhanced.live/live/mpc/enl0eG1mLmVncmVzcy5mZDJ2eHI=/out/v1/IT_SIMULCAST/FOODNETWORK/CMAF/index.m3u8) | <img height="20" src="https://i.imgur.com/i60OYr9.png"/> | Food.Network.it |
| 34  | Cine34   Ⓖ   | [>](https://live02-seg.msf.cdn.mediaset.net/live/ch-b6/b6-clr.isml/index.m3u8) | <img height="20" src="https://i.imgur.com/YyldwhI.png"/> | Cine34.it |
| 35  | Focus Ⓖ     | [>](https://live02-seg.msf.cdn.mediaset.net/live/ch-fu/fu-clr.isml/index.m3u8) | <img height="20" src="https://i.imgur.com/M4smqpF.png"/> | Focus.it |
| 36  | RTL 102.5      | [>](https://dd782ed59e2a4e86aabf6fc508674b59.msvdn.net/live/S97044836/tbbP8T1ZRPBL/playlist.m3u8) | <img height="20" src="https://i.imgur.com/KdissvS.png"/> | RTL.102.5.HD.it |
| 37  | Discovery Channel | [>](https://streaming.aurora.enhanced.live/live/mpc/enl0eG1mLmVncmVzcy5mZDJ2eHI=/out/v1/IT_SIMULCAST/DISCOVERYCHANNEL/CMAF/index.m3u8) | <img height="20" src="https://i.imgur.com/5IxIFJ0.png"/> | Discovery.Channel.it |
| 38  | Giallo         | [>](https://streaming.aurora.enhanced.live/live/mpc/enl0eG1mLmVncmVzcy5mZDJ2eHI=/out/v1/IT_SIMULCAST/GIALLO/CMAF/index.m3u8) | <img height="20" src="https://i.imgur.com/0PIRwZS.png"/> | Giallo.TV.it |
| 39  | Top Crime   Ⓖ | [>](https://live02-seg.msf.cdn.mediaset.net/live/ch-lt/lt-clr.isml/index.m3u8) | <img height="20" src="https://i.imgur.com/RFIwv9O.png"/> | Top.Crime.it |
| 40  | BOING   Ⓖ     | [>](https://live02-seg.msf.cdn.mediaset.net/live/ch-kb/kb-clr.isml/index.m3u8) | <img height="20" src="https://i.imgur.com/niSlrqT.png"/> | Boing.it |
| 42  | Rai Gulp Ⓖ    | [>](https://mediapolis.rai.it/relinker/relinkerServlet.htm?cont=746953&output=7&forceUserAgent=rainet/4.0.5) | <img height="20" src="https://i.imgur.com/lu1DPVb.png"/> | RaiGulp.it |
| 43  | Rai YoYo Ⓖ    | [>](https://mediapolis.rai.it/relinker/relinkerServlet.htm?cont=746899&output=7&forceUserAgent=rainet/4.0.5) | <img height="20" src="https://i.imgur.com/DRSa3ys.png"/> | RaiYoyo.it |
| 46  | Cartoonito Ⓖ  | [>](https://live02-seg.msf.cdn.mediaset.net/live/ch-la/la-clr.isml/index.m3u8) | <img height="20" src="https://i.imgur.com/oK2DcDJ.png"/> | Cartoonito.it |
| 47  | Super!        | [>](https://495c5a85d9074f29acffeaea9e0215eb.msvdn.net/super/super_main/super_main_hbbtv/playlist.m3u8) | <img height="20" src="https://thumb.wikimedia.org/wikipedia/commons/thumb/d/d8/Super%21_logo_2015.svg/330px-Super%21_logo_2015.svg.png"/> | Super!.it |
| 48  | Rai News 24   | [>](https://d3k8wzt41aflvx.cloudfront.net/RAINEWS24/Live.m3u8) | <img height="20" src="https://i.imgur.com/gdzGwB6.png"/> | RaiNews24.it |
| 48  | Rai News 24 Ⓖ | [>](https://mediapolis.rai.it/relinker/relinkerServlet.htm?cont=1&output=7&forceUserAgent=rainet/4.0.5) | <img height="20" src="https://i.imgur.com/gdzGwB6.png"/> | RaiNews24.it |
| 49  | Italia 2 Ⓖ    | [>](https://live02-seg.msf.cdn.mediaset.net/live/ch-i2/i2-clr.isml/index.m3u8) | <img height="20" src="https://i.imgur.com/nq48sjO.png"/> | Italia.2.it |
| 50  | Sky TG24 Ⓖ    | [>](https://hlslive-web-gcdn-skycdn-it.akamaized.net/TACT/12221/web/master.m3u8?hdnts=st=1764666351~exp=1829466206~acl=/*~hmac=b0e9165b6c55027903ad103c8219f363d8765eb300c0d9a339e9767fc3509556) | <img height="20" src="https://i.imgur.com/q4d3Dah.png"/> | Sky.TG24.it |
| 51  | TGCOM 24      | [>](https://d3k8wzt41aflvx.cloudfront.net/TGCOM24/Live.m3u8) | <img height="20" src="https://i.imgur.com/xautVD8.png"/> | TGCom.it |
| 51  | TGCOM 24 Ⓖ  | [>](https://live02-seg.msf.cdn.mediaset.net/live/ch-kf/kf-clr.isml/index.m3u8) | <img height="20" src="https://i.imgur.com/xautVD8.png"/> | TGCom.it |
| 52  | DMAX           | [>](https://streaming.aurora.enhanced.live/live/mpc/enl0eG1mLmVncmVzcy5mZDJ2eHI=/out/v1/IT_SIMULCAST/DMAX/CMAF/index.m3u8) | <img height="20" src="https://i.imgur.com/dmEmRX7.png"/> | DMAX.it |
| 54  | Rai Storia    | [>](https://d3k8wzt41aflvx.cloudfront.net/RAIStoria/Live.m3u8) | <img height="20" src="https://i.imgur.com/K8y5q8x.png"/> | RaiStoria.it |
| 54  | Rai Storia Ⓖ  | [>](https://mediapolis.rai.it/relinker/relinkerServlet.htm?cont=746990&output=7&forceUserAgent=rainet/4.0.5) | <img height="20" src="https://i.imgur.com/K8y5q8x.png"/> | RaiStoria.it |
| 55  | Mediaset Extra Ⓖ | [>](https://live02-seg.msf.cdn.mediaset.net/live/ch-kq/kq-clr.isml/index.m3u8) | <img height="20" src="https://i.imgur.com/mM8lopo.png"/> | Mediaset.Extra.it |
| 56  | HGTV – Home & Garden Tv  | [>](https://streaming.aurora.enhanced.live/live/mpc/enl0eG1mLmVncmVzcy5mZDJ2eHI=/out/v1/IT_SIMULCAST/HGTV/CMAF/index.m3u8) | <img height="20" src="https://i.imgur.com/emLNC0U.png"/> | HGTVItaly.it |
| 57  | Rai Scuola    | [>](https://d3k8wzt41aflvx.cloudfront.net/RAIScuola/Live.m3u8) | <img height="20" src="https://i.imgur.com/tmtJW6s.png"/> | RaiScuola.it |
| 57  | Rai Scuola Ⓖ  | [>](https://mediapolis.rai.it/relinker/relinkerServlet.htm?cont=747011&output=7&forceUserAgent=rainet/4.0.5) | <img height="20" src="https://i.imgur.com/tmtJW6s.png"/> | RaiScuola.it |
| 58  | Rai Sport Ⓖ   | [>](https://mediapolis.rai.it/relinker/relinkerServlet.htm?cont=358025&output=7&forceUserAgent=rainet/4.0.5) | <img height="20" src="https://i.imgur.com/xsGljsb.png"/> | RaiSport.it |
| 59  | Turbo    | [>](https://streaming.aurora.enhanced.live/live/mpc/enl0eG1mLmVncmVzcy5mZDJ2eHI=/out/v1/IT_SIMULCAST/TURBO/CMAF/index.m3u8) | <img height="20" src="https://i.imgur.com/TjjVjV0.png"/> | Motor.Trend.it |
| 60  | Sportitalia Plus | [>](https://sportsitalia-samsungitaly.amagi.tv/playlist.m3u8) | <img height="20" src="https://i.imgur.com/hu56Ya5.png"/> | Sportitalia.it |
| 61  | Travel TV        | [>](https://5a1178b42cc03.streamlock.net/travel/travel/playlist.m3u8) | <img height="20" src="https://i.imgur.com/aXAUyLN.png"/> | TravelTV.it |
| 62  | Donna TV Ⓢ     | [>](https://5f11919dca3bd.streamlock.net/donnatv/donnatv/playlist.m3u8) | <img height="20" src="https://i.imgur.com/Aa1Abme.png"/> | DonnaTV.it |
| 64  | SuperTennis    | [>](https://live-embed.supertennix.hiway.media/restreamer/supertennix_client/gpu-a-c0-16/restreamer/outgest/aa3673f1-e178-44a9-a947-ef41db73211a/manifest.m3u8) | <img height="20" src="https://i.imgur.com/GzsPlbX.png"/> | SuperTennis.it |
| 65  | Alma TV        | [>](https://5f11919dca3bd.streamlock.net/almatv/almatv/playlist.m3u8) | <img height="20" src="https://i.imgur.com/Y8JiDwN.png"/> | AlmaTV.it |
| 66  | Radio 105 TV Ⓖ | [>](https://live02-seg.msr.cdn.mediaset.net/live/ch-ec/ec-clr.isml/index.m3u8) | <img height="20" src="https://i.imgur.com/3NiLKvj.png"/> | Radio105TV.it |
| 67  | R101 TV Ⓖ    | [>](https://live02-seg.msr.cdn.mediaset.net/live/ch-er/er-clr.isml/index.m3u8) | <img height="20" src="https://i.imgur.com/mWeEa9T.png"/> | R101TV.it |
| 69  | Deejay TV      | [>](https://4c4b867c89244861ac216426883d1ad0.msvdn.net/live/S85984808/sMO0tz9Sr2Rk/playlist.m3u8) | <img height="20" src="https://i.imgur.com/rlaKH6k.png"/> | DeejayTV.it |
| 70  | RadioItaliaTV   | [>](https://radioitaliatv.akamaized.net/hls/live/2093117/RadioitaliaTV/master.m3u8) | <img height="20" src="https://i.imgur.com/4VCEJuJ.png"/> | RadioItaliaTV.it |
| 158 | Radio KISS KISS TV | [>](https://kk.fluid.stream/KKMulti/smil:KissKissTV.smil/playlist.m3u8) | <img height="20" src="https://i.imgur.com/UTStxDW.png"/> | KissKissTV.it |
| 202 | Rai Radio 2 Visual Radio | [>](https://mediapolis.rai.it/relinker/relinkerServlet.htm?cont=5674080&output=7&forceUserAgent=rainet/4.0.5) | <img height="20" src="https://i.imgur.com/nVBet0h.png"/> | RaiRadio2Visual.it |
| 233 | RTL 102.5 Traffic | [>](https://dd782ed59e2a4e86aabf6fc508674b59.msvdn.net/live/S38122967/2lyQRIAAGgRR/playlist.m3u8) | <img height="20" src="https://i.imgur.com/GH7byqm.jpeg"/> | RTL1025Traffic.it |
| 236 | MAN-GA | [>](https://c65b9e710bde44819015af98e72cd7ab.msvdn.net/live/S93572876/aILSQPYFY3pF/playlist.m3u) | <img height="20" src="https://i.imgur.com/8a6WYU2.png"/> | Manga.it |
| 246 | Radio24-IlSole24OreTV | [>](https://ilsole24ore-radiovisual.akamaized.net/hls/live/2035302/persidera/master.m3u8) | <img height="20" src="https://i.imgur.com/NTqrdWW.png"/> | Radio24TV.it |
| 247 | BeJoy.Kids | [>](https://stream.paroledivita.org/bejoy.m3u8) | <img height="20" src="https://i.imgur.com/zuR9Go5.png"/> | BeJoyKids.it |
| 257 | Gambero Rosso  | [>](https://cdndirector.dailymotion.com/cdn/live/video/x9us6y4.m3u8?sec=h5bGwJYFZy9AO66NpfTxbhTni9e637DUu_SUPhn3MewWKmiD4Rmw0UuwfufSVb3G) | <img height="20" src="https://i.imgur.com/RApMW5x.png"/> | GamberoRosso.it |
| 258 | RadioFreccia   | [>](https://dd782ed59e2a4e86aabf6fc508674b59.msvdn.net/live/S3160845/0tuSetc8UFkF/playlist.m3u8) | <img height="20" src="https://i.imgur.com/J5N9F7Z.png"/> | RadioFrecciaTV.it |
| 265 | RDS Social TV | [>](https://stream.rdstv.radio/index.m3u8) | <img height="20" src="https://i.imgur.com/TY6FhqI.png"/> | RDSSocialTV.it |
| 266 | Radio ZETA     | [>](https://dd782ed59e2a4e86aabf6fc508674b59.msvdn.net/live/S9346184/XEx1LqlYbNic/playlist.m3u8) | <img height="20" src="https://i.imgur.com/0MgCm1n.png"/> | RadioZetaTV.it |
| 899 | Radio TV Serie A | [>](https://legaseriea-live-prd.cdn.netrw.it/out/v1/s-prd/ch-01-prd-s-v2/hls-ch-01-prd-s-hd/index%2Em3u8) | <img height="20" src="https://i.imgur.com/2AvxGJF.png"/> | RadioTVSerieA.it |

<h2>Satellite</h2>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 0   | Mediaset Italia - America | [>](https://d3k8wzt41aflvx.cloudfront.net/MediasetUSA/Live.m3u8) | <img height="20" src="https://i.imgur.com/oh8ihqr.png"/> | Mediaset.Italia.-.America.it |
| 0   | Mediaset Italia - Australia e Asia | [>](https://d3k8wzt41aflvx.cloudfront.net/Mediaset_AU/Live.m3u8) | <img height="20" src="https://i.imgur.com/oh8ihqr.png"/> | Mediaset.Italia.-.Australia.e.Asia.it |
| 0   | Mediaset Italia - Europa e Africa | [>](https://d3k8wzt41aflvx.cloudfront.net/MediasetEU/Live.m3u8) | <img height="20" src="https://i.imgur.com/oh8ihqr.png"/> | Mediaset.Italia.-.Europa.e.Africa.it |
| 0   | Rai Italia Asia e Australia | [>](https://d3k8wzt41aflvx.cloudfront.net/RAIHD/Live.m3u8) | <img height="20" src="https://i.imgur.com/riXPOTh.png"/> |
| 0   | Rai Italia Europa e Africa | [>](https://d3k8wzt41aflvx.cloudfront.net/RAIEU/Live.m3u8) | <img height="20" src="https://i.imgur.com/riXPOTh.png"/> |
| 0   | Rai Italia Nord America | [>](https://d3k8wzt41aflvx.cloudfront.net/RAIUSA/Live.m3u8) | <img height="20" src="https://i.imgur.com/riXPOTh.png"/> | RaiItaliaAmerica.it |
| 0   | Rai Italia Sud America | [>](https://d3k8wzt41aflvx.cloudfront.net/RAISA/Live.m3u8) | <img height="20" src="https://i.imgur.com/riXPOTh.png"/> |
| 0   | Rai World Premium | [>](https://d3k8wzt41aflvx.cloudfront.net/RAIP/Live.m3u8) | <img height="20" src="https://i.imgur.com/q1EHOhz.png"/> |
| 58  | Sportitalia SOLOCALCIO Ⓖ | [>](https://distribution.sportitalialive.it/sportitalia/sisolocalcio_abr/playlist.m3u8) | <img height="20" src="https://i.imgur.com/hu56Ya5.png"/> | SportitaliaSolocalcio.it |
| 67  | Radio Montecarlo TV Ⓖ | [>](https://live02-seg.msr.cdn.mediaset.net/live/ch-bb/bb-clr.isml/index.m3u8) | <img height="20" src="https://i.imgur.com/3TMMXmS.png"/> | RadioMonteCarloTV.it |
| 68  | Virgin Radio TV Ⓖ | [>](https://live02-seg.msr.cdn.mediaset.net/live/ch-ew/ew-clr.isml/index.m3u8) | <img height="20" src="https://i.imgur.com/7Im3HI1.png"/> | VirginRadioTV.it |
| 89  | Senato TV      | [>](https://senato-live.morescreens.com/SENATO_1_001/playlist.m3u8) | <img height="20" src="https://i.imgur.com/FoQoNZW.png"/> | SenatoTV.it |
| 90  | Camera dei Deputati Ⓢ | [>](https://video-ar.radioradicale.it/diretta/camera2/playlist.m3u8) | <img height="20" src="https://i.imgur.com/fqGn1k9.png"/> | CameradeiDeputati.it |
| 210 | Rai 4K Ⓖ       | [>](https://raievent10-elem-live.akamaized.net/hls/live/619189/raievent10/raievent10/playlist.m3u8) | <img height="20" src="https://i.imgur.com/5gkt9DD.png"/> | Rai4K.it |
| 507 | Class CNBC Ⓖ | [>](https://amg14891-amg14891c5-amgplt0020.playout.now3.amagi.tv/playlist.m3u8) | <img height="20" src="https://i.imgur.com/oAiSU8O.png"/> | Class.CNBC.it |
| 701 | UniNettuno University TV Ⓖ | [>](https://stream6-rai-it.akamaized.net/live/uninettuno/playlist.m3u8) | <img height="20" src="https://i.imgur.com/BOGMeio.png"/> | UniNettunoUniversityTV.it |

<h2>Regional DVB-T</h2>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 0   | 111 Tv | [>](https://5db313b643fd8.streamlock.net/111/111/playlist.m3u8) | <img height="20" src="https://i.imgur.com/4jY8yAI.png"/> |
| 0   | 12 Tv Parma | [>](https://5929b138b139d.streamlock.net/12TVParma/livestream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/xnUgx6b.png"/> | 12TVParma.it |
| 0   | 4 You Tv | [>](https://streamsrv2.nets-sr.com:19360/4youtv/4youtv.m3u8) | <img height="20" src="https://i.imgur.com/NN0cSbz.png"/> |
| 0   | Abc Tv | [>](https://diretta.arcapuglia.it:8080/live/abctv/index.m3u8) | <img height="20" src="https://i.imgur.com/nVmIeTD.png"/> |
| 0   | AB Channel  | [>](https://tsw.streamingwebtv24.it:1936/abchanneltv/abchanneltv/playlist.m3u8) | <img height="20" src="https://i.imgur.com/k8EPLB9.png"/> | ABChannel.it |
| 0   | Alpauno | [>](https://5f22d76e220e1.streamlock.net/alpaunotv/alpaunotv/playlist.m3u8) | <img height="20" src="https://i.imgur.com/4QKFtUa.png"/> |
| 0   | Alto Adige Tv | [>](https://5f204aff97bee.streamlock.net/AltoAdigeTV/livestream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/S2sCFQi.png"/> | AltoAdigeTV.it |
| 84  | AM Terni Television | [>](https://stream9.xdevel.com/video0s976364-1176/stream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/XLuIz5j.png"/> |
| 0   | Antenna 2 Bergamo | [>](https://58f12ffd2447a.streamlock.net/Antenna2/livestream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/NfvHIAw.png"/> |
| 0   | Antenna 3 Massa | [>](https://media2021.rtvweb.com/antenna3massa/a3/playlist.m3u8) | <img height="20" src="https://i.imgur.com/CHDU86j.png"/> |
| 0   | Antenna 3 Veneto Nord Est | [>](https://59d7d6f47d7fc.streamlock.net/antennatreveneto/antennatreveneto.stream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/NiVHLwp.png"/> | AntennaTreNordest.it |
| 10  | Antenna Sicilia | [>](https://antennasicilialive.cdn.netrw.it/antennasicilialive/hls/ccr/antennasicilia/master.m3u8) | <img height="20" src="https://i.imgur.com/8DOdqsE.png"/> |
| 0   | Antenna Sud | [>](https://live-antennasud.cdn.netrw.it/antennasud/hls/ccr/antennasud/master.m3u8) | <img height="20" src="https://i.imgur.com/b8y6ImZ.png"/> |
| 0   | Antenna Sud Extra | [>](https://live-antennasud.cdn.netrw.it/antennasud/hls/ccr/extra/master.m3u8) | <img height="20" src="https://i.imgur.com/6tBv8VD.png"/> |
| 0   | Aristanis SuperTv | [>](https://video2.azotosolutions.com:1936/supertvoristano/supertvoristano/playlist.m3u8) | <img height="20" src="https://i.imgur.com/v8PlAJO.png"/> |
| 0   | Arte Network Orler | [>](https://tsw.streamingwebtv24.it:1936/artenetwork/artenetwork/playlist.m3u8) | <img height="20" src="https://i.imgur.com/DP5y0Er.png"/> |
| 0   | Aurora Arte | [>](https://59d7d6f47d7fc.streamlock.net/auroraarte/auroraarte/playlist.m3u8) | <img height="20" src="https://i.imgur.com/BoLZ5wG.png"/> | AuroraArte.it |
| 0   | Azzurra Tv Vco | [>](https://ed05.top-ix.org/avtvlive/azzurra/streaming/playlist.m3u8) | <img height="20" src="https://i.imgur.com/mSWw8uW.png"/> | AzzurraTV.it |
| 0   | Basilicata 1 Tv | [>](http://77.68.40.210:8888/hls/basilicata1.m3u8) | <img height="20" src="https://i.imgur.com/VS6CQ88.png"/> |
| 0   | Bella e Monella TV | [>](https://58d921499d3d3.streamlock.net/RadioBelllaemonellaTV/livestream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/yZONx5f.png"/> |
| 0   | Bergamo Tv | [>](https://db142859fd5541b09de25d6507f1f2d3.msvdn.net/live/S17501676/oIxAsgEEA46M/playlist.m3u8?DVR) | <img height="20" src="https://i.imgur.com/1doR6Vl.png"/> |
| 0   | BOM Channel | [>](https://5f22d76e220e1.streamlock.net/canale6/canale6/playlist.m3u8) | <img height="20" src="https://i.imgur.com/hISoOK3.png"/> | BomChannel.it |
| 0   | ByoBlu | [>](https://09bd1346f7a44cc9ac230cc1cb22ca4f.msvdn.net/live/S39249178/EnTK3KeeN1Eg/playlist.m3u8) | <img height="20" src="https://i.imgur.com/1xaHGtU.png"/> |
| 0   | Cafe Tv 24 | [>](https://srvx1.selftv.video/cafe/live/playlist.m3u8) | <img height="20" src="https://i.imgur.com/KbcbxFw.png"/> |
| 0   | Calabria Uno Tv  | [>](https://635320cd397eb.streamlock.net/live/calabriaunolive/playlist.m3u8) | <img height="20" src="https://i.imgur.com/2TK1GQ5.png"/> |
| 0   | Calabria tv | [>](https://64b16f23efbee.streamlock.net/calabriatv/calabriatv/playlist.m3u8) | <img height="20" src="https://i.imgur.com/qWirucd.png"/> |
| 0   | Canale 10 | [>](https://nrvideo1.newradio.it:1936/desxcerbht/desxcerbht/playlist.m3u8) | <img height="20" src="https://i.imgur.com/KuQcjYV.png"/> |
| 0   | Canale 2 | [>](https://59d7d6f47d7fc.streamlock.net/canale2/canale2/playlist.m3u8) | <img height="20" src="https://i.imgur.com/ETqDkS1.png"/> |
| 0   | Canale 21 | [>](https://ch21napoli-cdn.encoders.immergo.tv/master.m3u8) | <img height="20" src="https://i.imgur.com/mU6Cq89.png"/> | Canale21.it |
| 0   | Canale 21 Extra | [>](https://ch21extra-cdn.encoders.immergo.tv/master.m3u8) | <img height="20" src="https://i.imgur.com/cDAsrBl.png"/> | Canale21Extra.it |
| 0   | Canale 7 | [>](http://wms.shared.streamshow.it:80/canale7/canale7/playlist.m3u8) | <img height="20" src="https://i.imgur.com/9cuOLCn.png"/> |
| 0   | Canale 74 Sicilia | [>](https://stream.cp.ets-sistemi.it:1936/canale74/canale74/playlist.m3u8) | <img height="20" src="https://i.imgur.com/18JIVgu.png"/> |
| 0   | Canale 8 Campania | [>](https://59d7d6f47d7fc.streamlock.net/canale8/canale8/playlist.m3u8) | <img height="20" src="https://i.imgur.com/ElAS2WC.png"/> |
| 0   | Canale Italia  | [>](https://ovp-live.akamaized.net/ac115_live/canale1.smil/playlist.m3u8) | <img height="20" src="https://i.imgur.com/QlwLRyh.png"/> | CanaleItalia.it |
| 0   | Carina Tv | [>](https://samson.streamerr.co:8081/carinatv/index.m3u8) | <img height="20" src="https://i.imgur.com/FMGcm6I.jpg"/> |
| 0   | Casa Italia 53 | [>](https://ovp-live.akamaized.net/ac115_live/canale3.smil/playlist.m3u8) | <img height="20" src="https://i.imgur.com/O4GQVCk.png"/> |
| 0   | Casa Sanremo Tv | [>](https://router.xdevel.com/video0s975911-633/stream/playlist_dvr.m3u8) | <img height="20" src="https://i.imgur.com/WL3SFTs.png"/> |
| 0   | Castrovillari Tv | [>](http://msh0062.stream.seeweb.it/live/flv:stream00.sdp/playlist.m3u8) | <img height="20" src="https://i.imgur.com/V0kjYNG.png"/> |
| 0   | Cittaceleste Tv | [>](https://sportitaliaamd.akamaized.net/live/Cittaceleste/hls/A990687F506536598442FC5CD12C97CB78873FBA/index.m3u8) | <img height="20" src="https://i.imgur.com/9RVriNK.jpeg"/> |
| 0   | Company Tv | [>](https://company.fluid.stream/CompanyTV/smil:Company_ALL.smil/playlist.m3u8) | <img height="20" src="https://i.imgur.com/IbabUDd.png"/> |
| 0   | Cremona 1 | [>](https://cdn2.streamshow.it/cloud-cremona1/cremona1/playlist.m3u8) | <img height="20" src="https://i.imgur.com/a5d0F01.jpg"/> |
| 0   | Cusano Italia Tv | [>](https://router.xdevel.com/video0s975363-69/stream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/9F1sVjZ.png"/> |
| 0   | Cusano News 7 | [>](https://router.xdevel.com/video1s975363-1596/stream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/L49Ie1Q.png"/> |
| 0   | Delta Tv | [>](http://hbbtv-server.zivoli.it:8080/hls/deltatv/deltatv/index.m3u8) | <img height="20" src="https://i.imgur.com/mfwVXt7.png"/> |
| 0   | Deluxe 139 | [>](https://59d7d6f47d7fc.streamlock.net/pierstyle/pierstyle/playlist.m3u8) | <img height="20" src="https://i.imgur.com/kRexw3w.png"/> |
| 0   | Di.Tv 80 | [>](https://5f22d76e220e1.streamlock.net/ditv80/ditv80/playlist.m3u8) | <img height="20" src="https://i.imgur.com/kHxTsJw.png"/> |
| 0   | Di.Tv 92 | [>](https://media2021.rtvweb.com/di_tv_92/live/playlist.m3u8) | <img height="20" src="https://i.imgur.com/g3SI08H.png"/> |
| 0   | Digital Tv7 Benevento | [>](http://streaming.senecadot.com/live/flv:tv7.sdp/playlist.m3u8) | <img height="20" src="https://i.imgur.com/NaQkklP.png"/> |
| 0   | Donna Shopping Tv | [>](https://5f22d76e220e1.streamlock.net/fascinotv/fascinotv/playlist.m3u8) | <img height="20" src="https://i.imgur.com/oLDvx2T.png"/> |
| 0   | E'live Brescia Tv | [>](https://59d7d6f47d7fc.streamlock.net/elivebresciatv/elivebresciatv/playlist.m3u8) | <img height="20" src="https://i.imgur.com/bZ3B7pi.png"/> |
| 0   | Easy Tv Canale 190 | [>](https://diretta.arcapuglia.it:8080/live/easytv/index.m3u8) | <img height="20" src="https://i.imgur.com/LKrVuRR.jpg"/> |
| 0   | Enjoy Television | [>](https://str27.fluid.stream/EnjoyTelevision/livestream/playlist.m3u8) | <img height="20" src="https://hostux.pics/images/2026/09/11/04_enjoy_television1ad11f59484e0115.png"/> |
| 0   | Entella Tv | [>](https://5f22d76e220e1.streamlock.net:443/EntellaTV/EntellaTV/playlist.m3u8) | <img height="20" src="https://i.imgur.com/1VPXKrW.png"/> |
| 0   | EQUtv | [>](https://ippicabetflag-live.morescreens.com/IPPICA_1_003/304p.m3u8) | <img height="20" src="https://i.imgur.com/x9Wdz7h.png"/> |
| 0   | Equos Tv | [>](https://dacastmmd.mmdlive.lldns.net/dacastmmd/2824fb123d5e44b797232c7abf8195da/playlist.m3u8) | <img height="20" src="https://i.imgur.com/YwyfNDF.png"/> |
| 0   | Espansione Tv | [>](https://srvx1.selftv.video/espansione/smil:live.smil/playlist.m3u8) | <img height="20" src="https://i.imgur.com/mm9HKpD.png"/> | EspansioneTV.it |
| 0   | Esperia Tv | [>](https://59d7d6f47d7fc.streamlock.net/esperiatv/esperiatv/playlist.m3u8) | <img height="20" src="https://patbuweb.com/tivustream/chanlogoz/ita/esperiatv.png"/> |
| 0   | Etna Espresso Channel | [>](https://5db313b643fd8.streamlock.net/Etnachannelponte/Etnachannelponte/playlist.m3u8) | <img height="20" src="https://i.imgur.com/hMUxytZ.png"/> |
| 0   | è Tv Marche | [>](https://live.ipstream.it/etvmarche/etvmarche.stream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/vxgbFnR.png"/> |
| 0   | è Tv Rete7 | [>](https://live.ipstream.it/etv/etv.stream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/FXFzJhM.png"/> |
| 0   | è Tv Umbria | [>](https://live.ipstream.it/etvumbria/etvumbria.stream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/DASRCe2.png"/> |
| 0   | Euro Tv | [>](https://5f22d76e220e1.streamlock.net/eurotv/eurotv/playlist.m3u8) | <img height="20" src="https://i.imgur.com/HCl5Zbu.png"/> |
| 0   | Extra Tv | [>](https://rst2.saiuzwebnetwork.it:8081/extratvlive/index.m3u8) | <img height="20" src="https://i.imgur.com/KCBurST.png"/> |
| 0   | FM Tv Marche | [>](https://bbtv.intvstream.net:3988/hybrid/play.m3u8) | <img height="20" src="https://i.imgur.com/yY01NhL.jpg"/> |
| 0   | Fano Tv | [>](https://diretta.arcapuglia.it:8080/live/fanotv/index.m3u8) | <img height="20" src="https://i.imgur.com/orqEzJ6.png"/> |
| 0   | Fascino Tv | [>](https://64b16f23efbee.streamlock.net/canale157/canale157/playlist.m3u8) | <img height="20" src="https://i.imgur.com/4XYYY5B.png"/> |
| 0   | GRP Televisione | [>](https://webstream.multistream.it/memfs/a3195c96-f884-4c74-924f-2648814fc0b5.m3u8) | <img height="20" src="https://i.imgur.com/1zNPpVE.png"/> |
| 0   | GarganoTv | [>](https://cdn80-ger.azotosolutions.com:8443/cdnedge3/smil:live3.smil/playlist.m3u8) | <img height="20" src="https://i.imgur.com/OlJohKK.png"/> |
| 0   | Giornale Radio Tv | [>](https://5f204aff97bee.streamlock.net/GR_tv/livestream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/TMtvCLL.jpg"/> |
| 0   | Giovanni Paolo Tv | [>](https://media2021.rtvweb.com/giovannipaolotv/web/chunklist_w663456797.m3u8) | <img height="20" src="https://i.imgur.com/GH5eJE6.png"/> |
| 0   | Globo Tv | [>](https://nrvideo1.newradio.it:1936/awrgaebshj/awrgaebshj/playlist.m3u8) | <img height="20" src="https://i.imgur.com/lR08pb3.jpeg"/> |
| 0   | Globus Television | [>](https://cdn.cubws.com/live/globus.m3u8) | <img height="20" src="https://i.imgur.com/yUTYqCv.png"/> |
| 0   | Gold Tv  | [>](https://5f11919dca3bd.streamlock.net/goldtv/goldtv/playlist.m3u8) | <img height="20" src="https://i.imgur.com/3rVi4kD.png"/> | GoldTV.it |
| 0   | GO-TV Channel | [>](https://6zklxkbbdw9b-hls-live.mariatvcdn.it/msmotor/2f759512164fc6fe4acbed6a5648993a.sdp/playlist.m3u8) | <img height="20" src="https://i.imgur.com/xgjrAAn.png"/> | GOTVCanale163.it |
| 0   | GS Channel | [>](https://rst.saiuzwebnetwork.it:8081/retereggio/index.m3u8) | <img height="20" src="https://i.imgur.com/ExfxCRv.png"/> |
| 0   | Icaro Tv Rimini | [>](https://59d7d6f47d7fc.streamlock.net/icarotv/icarotv/playlist.m3u8) | <img height="20" src="https://i.imgur.com/z05VSSN.png"/> |
| 0   | Idea Plus | [>](https://rst.saiuzwebnetwork.it:19360/teleidea/teleidea.m3u8) | <img height="20" src="https://i.imgur.com/2edmxYF.png"/> |
| 0   | il61 | [>](https://5a1178b42cc03.streamlock.net/travel/travel/playlist.m3u8) | <img height="20" src="https://i.imgur.com/1rUZsBv.png"/> |
| 0   | Italia 2 Tv | [>](https://59d7d6f47d7fc.streamlock.net/italia2/italia2/playlist.m3u8) | <img height="20" src="https://i.imgur.com/ISbxfY0.png"/> | Italia2TV.it |
| 0   | Italia 7 | [>](https://5f11919dca3bd.streamlock.net/italia7/italia7/playlist.m3u8) | <img height="20" src="https://i.imgur.com/YBXkY4w.png"/> |
| 0   | Italia 8 Prestige | [>](https://5f22d76e220e1.streamlock.net/italia8prestige/italia8prestige/playlist.m3u8) | <img height="20" src="https://i.imgur.com/uDxWI4a.png"/> |
| 0   | Italia Channel | [>](https://stream1.aswifi.it/italiachannel/stream/index.m3u8) | <img height="20" src="https://i.imgur.com/zuuKXGv.png"/> | ItaliaChannel.it |
| 0   | Iunior Tv | [>](https://5f22d76e220e1.streamlock.net/iuniortv/iuniortv/playlist.m3u8) | <img height="20" src="https://i.imgur.com/9jeNlLE.png"/> | IuniorTV.it |
| 0   | L'Altro Corriere Tv  | [>](https://stream.cp.ets-sistemi.it:1936/laltrocorriere-tv/laltrocorriere-tv/playlist.m3u8) | <img height="20" src="https://i.imgur.com/dgj79J3.png"/> |
| 0   | La Nuova Tv | [>](https://5dcabf026b188.streamlock.net/lanuovatvbas/livestream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/wg8FhdN.png"/> |
| 0   | La Tenda Tv | [>](https://2-fss-1.streamhoster.com/pl_148/206202-2980948-1/playlist.m3u8) | <img height="20" src="https://i.imgur.com/XnBp0hT.png"/> |
| 0   | La tr3 Marsala | [>](https://tsw.streamingwebtv24.it:1936/eslife1/eslife1/playlist.m3u8) | <img height="20" src="https://i.imgur.com/XlxpfEx.png"/> |
| 0   | LaC News 24 | [>](https://f5842579ff984c1c98d63b8d789673eb.msvdn.net/live/S27391994/HVvPMzy/playlist.m3u8) | <img height="20" src="https://i.imgur.com/02vCECa.png"/> |
| 0   | LaC Tv Calabria | [>](https://f5842579ff984c1c98d63b8d789673eb.msvdn.net/live/S47282891/JWjL3xqPf4bX/playlist.m3u8) | <img height="20" src="https://i.imgur.com/2Ef6crS.png"/> |
| 0   | Lab Tv | [>](https://customer-yzibk50951uq418a.cloudflarestream.com/a58893dee4b9922a75e41b4ec4243f84/manifest/video.m3u8) | <img height="20" src="https://i.imgur.com/OpRS6Fl.png"/> |
| 0   | Lazio Tv | [>](https://5f11919dca3bd.streamlock.net/laziotv/laziotv/playlist.m3u8) | <img height="20" src="https://i.imgur.com/DAj5Uwb.png"/> |
| 0   | Le Cronache Lucane Tv | [>](http://stucazz.com:8888/hls/cronache.m3u8) | <img height="20" src="https://i.imgur.com/EBY3IZL.jpg"/> |
| 0   | Lira Tv | [>](https://a928c0678d284da5b383f29ecc5dfeec.msvdn.net/live/S57315730/8kTBWibNteJA/playlist.m3u8) | <img height="20" src="https://i.imgur.com/S0ReVEo.png"/> |
| 0   | Lombardia Tv | [>](https://5db313b643fd8.streamlock.net/lmbiatv/lmbiatv/playlist.m3u8) | <img height="20" src="https://i.imgur.com/aksVy9f.jpg"/> |
| 0   | Love in Venice | [>](https://59d7d6f47d7fc.streamlock.net/loveinvenice/loveinvenice.stream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/lLBzzce.png"/> |
| 0   | Lucania Tv | [>](https://cdn15.streamshow.it/cloud-lucaniatv/lucaniatv/playlist.m3u8) | <img height="20" src="https://i.imgur.com/wuUNVR5.png"/> |
| 0   | Made in BO | [>](https://srvx1.selftv.video/dmchannel/live/playlist.m3u8) | <img height="20" src="https://i.imgur.com/WFnrMS0.png"/> |
| 0   | Maria Vision | [>](https://1601580044.rsc.cdn77.org/live/_jcn_/amls:CHANNEL_2/playlist.m3u8) | <img height="20" src="https://i.imgur.com/fdx5YXi.png"/> |
| 0   | Matrix Tv | [>](https://5f22d76e220e1.streamlock.net/GrandeItalia/GrandeItalia/playlist.m3u8) | <img height="20" src="https://i.imgur.com/m1HeXrn.png"/> |
| 0   | Mediterranea Tv | [>](https://stream10.xdevel.com/video1s975675-1403/stream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/GUTOqRt.png"/> |
| 0   | Medjugorje Italia Tv | [>](https://5f22d76e220e1.streamlock.net/medjugorjeitaliatv/medjugorjeitaliatv/playlist.m3u8) | <img height="20" src="https://i.imgur.com/hkZScXf.png"/> |
| 0   | Medjugorje Tv Puglia  | [>](https://diretta.arcapuglia.it:8080/live/medjugorietv/index.m3u8) | <img height="20" src="https://i.imgur.com/IWBeddh.png"/> |
| 0   | Minformo Tv | [>](https://5db313b643fd8.streamlock.net:443/MinformoTV/MinformoTV/playlist.m3u8) | <img height="20" src="https://i.imgur.com/VJNtnZM.jpg"/> |
| 0   | Motori Tv      | [>](https://64b16f23efbee.streamlock.net/servizio01/servizio01/playlist.m3u8) | <img height="20" src="https://i.imgur.com/NWXQKbl.png"/> |
| 0   | NTI Canale 271 | [>](https://www.ntimedia.it/video/S0B/S0B_master.m3u8) | <img height="20" src="https://i.imgur.com/zlmcUe0.jpg"/> |
| 0   | News24 City | [>](https://dc3.telesveva.com:4433/news24.mp4) | <img height="20" src="https://i.imgur.com/dak9AtV.png"/> |
| 0   | Nuova TV Nazionale | [>](https://stream4.xdevel.com/video0s975955-782/stream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/QWlRuXg.png"/> |
| 0   | Nuova Tv 1  | [>](https://nuovatv.net:8443/tv/stream.m3u8) | <img height="20" src="https://i.imgur.com/1yqTZhR.png"/> |
| 0   | Nuova Tv 2 | [>](https://nuovatv.net:8443/tv2/stream.m3u8) | <img height="20" src="https://i.imgur.com/0vauyV3.png"/> |
| 0   | Nuvola Tv | [>](https://stream.nuvola.tv:8181/memfs/4aaa6328-1879-4ebf-b18a-498146d0c61c.m3u8) | <img height="20" src="https://i.imgur.com/EDGez2x.png"/> |
| 0   | Odeon 24 | [>](https://streaming.softwarecreation.it/Odeon/Odeon/manifest.m3u8) | <img height="20" src="https://i.imgur.com/M1tVBuH.png"/> |
| 0   | Ofanto Tv | [>](https://videostream.isgm.it:3276/live/tvofantolive.m3u8) | <img height="20" src="https://i.imgur.com/UCgATWn.png"/> |
| 0   | Onda Novara Tv | [>](https://585b674743bbb.streamlock.net/9006/9006/playlist.m3u8) | <img height="20" src="https://i.imgur.com/Qoh9CFy.png"/> |
| 0   | Onda Tv Sicilia | [>](https://5926fc9c7c5b2.streamlock.net/9040/9040/playlist.m3u8) | <img height="20" src="https://i.imgur.com/0c5Y6lr.png"/> |
| 0   | Onda Web Radio | [>](http://178.33.224.197:1935/ondaradioweb/ondaradioweb/playlist.m3u8) | <img height="20" src="https://i.imgur.com/3hTvrC8.jpg"/> |
| 0   | Ora Tv | [>](https://5db313b643fd8.streamlock.net/OraTv/OraTv/playlist.m3u8) | <img height="20" src="https://i.imgur.com/clWVrvE.png"/> |
| 0   | Orler Tv | [>](https://w1.mediastreaming.it/orlertv/livestream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/dBkxD8e.png"/> |
| 0   | Otto Channel | [>](https://ottop-live-meride.akamaized.net/hls/live/2039996/ch1/playlist.m3u8) | <img height="20" src="https://i.imgur.com/HRonD2N.png"/> |
| 0   | Padre Pio Tv | [>](https://600f07e114306.streamlock.net/PadrePioTV/livestream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/7ajxEPH.png"/> |
| 0   | Paradise Tv | [>](https://tsw.streamingwebtv24.it:1936/paradisetv/paradisetv/playlist.m3u8) | <img height="20" src="https://i.imgur.com/okIBfIb.jpg"/> |
| 0   | Parole di Vita  | [>](https://stream.paroledivita.org/paroledivita.m3u8) | <img height="20" src="https://i.imgur.com/M9mIiZD.png"/> |
| 0   | Partenope Tv | [>](https://diretta.arcapuglia.it:8080/live/partenope/index.m3u8) | <img height="20" src="https://i.imgur.com/FtuWkj1.png"/> |
| 0   | Peer Tv Alto Adige | [>](https://iptv.peer.biz/live/peertv-it.m3u8) | <img height="20" src="https://www.peer.biz/peertv-iptv/peer-tv-alto-adige.png"/> | PeerTV.it |
| 2   | Peer TV Südtirol | [>](https://iptv.peer.biz/live/peertv.m3u8) | <img height="20" src="https://www.peer.biz/peertv-iptv/peer-tv-suedtirol.png"/> | PeerTV.de |
| 0   | Pop Tv | [>](https://stream1.aswifi.it/poptelevision/live/index.m3u8) | <img height="20" src="https://i.imgur.com/TeolCu9.png"/> |
| 0   | Prima Tv Napoli | [>](https://57068da1deb21.streamlock.net/primatvnapoli/primatvnapoli/playlist.m3u8) | <img height="20" src="https://i.imgur.com/yPuQeEy.jpg"/> |
| 0   | Prima Tv Sicilia | [>](https://5db313b643fd8.streamlock.net/PrimaTV/PrimaTV/playlist.m3u8) | <img height="20" src="https://i.imgur.com/br45JER.png"/> |
| 0   | PrimaFREE | [>](https://5f22d76e220e1.streamlock.net/primafree/primafree/playlist.m3u8) | <img height="20" src="https://i.imgur.com/YrSSmOL.png"/> |
| 0   | Primantenna Torino | [>](https://5f22d76e220e1.streamlock.net/primantenna14/primantenna14/playlist.m3u8) | <img height="20" src="https://i.imgur.com/sqEcPFs.gif"/> |
| 0   | Primocanale | [>](https://msh0203.stream.seeweb.it/live/flv:stream2.sdp/playlist.m3u8) | <img height="20" src="https://i.imgur.com/xWF1A1U.png"/> |
| 0   | Promovideo Tv | [>](https://media2021.rtvweb.com/promovideo_web/promovideo/playlist.m3u8) | <img height="20" src="https://i.imgur.com/MwK9HVG.png"/> |
| 0   | Quarto Canale Flegreo | [>](http://live.mariatvcdn.com/dialogos/171e41deedf405f10c7dd6311387fb43.sdp/playlist.m3u8) | <img height="20" src="https://i.imgur.com/8RKY3Du.png"/> |
| 0   | Radio 3M InBlu | [>](https://stream.mariatvcdn.com/telemistrettaradio/900bfcc0f9012ea272584fd5ff5281b8.sdp/playlist.m3u8) | <img height="20" src="https://i.imgur.com/d7O7Uqa.png"/> |
| 0   | Radio 51 Tv | [>](https://59d7d6f47d7fc.streamlock.net/canale51/canale51/chunklist_w1193883900.m3u8) | <img height="20" src="https://uaznao.com/wp-content/uploads/2023/03/radio51.png"/> |
| 0   | Radio Arancia TV | [>](https://stream3.xdevel.com/video0s975447-164/stream/playlist.m3u8) | <img height="20" src="https://hostux.pics/images/2026/09/11/05_radio_arancia_tv84cccbbd33923281.png"/> |
| 0   | Radio Bianconera TV | [>](https://tmw.fluid.stream/RadioBianconeraTV/livestream/playlist.m3u8) | <img height="20" src="https://hostux.pics/images/2026/09/11/06_radio_bianconera_tv4a5c7bf00662f7ba.png"/> |
| 0   | Radio Birikina Tv | [>](https://tvd-bk.fluid.stream/RadioBirikinaTV/livestream/chunklist_w84398277.m3u8) | <img height="20" src="https://uaznao.com/wp-content/uploads/2023/03/radiobirikina.png"/> |
| 0   | Radio Bruno Tv | [>](https://router.xdevel.com/video0s975758-473/stream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/y4vKE83.png"/> |
| 0   | Radio Delta 1 TV | [>](https://stream6.xdevel.com/video0s976486-1271/stream/playlist.m3u8) | <img height="20" src="https://hostux.pics/images/2026/09/11/07_radio_delta_1_tvc17419f8a8df1da6.png"/> |
| 0   | Radio Digiesse TV | [>](https://w1.mediastreaming.it/digiesse/livestream/playlist.m3u8) | <img height="20" src="https://hostux.pics/images/2026/09/11/08_radio_digiesse_tv62f4f919c0d901ef.png"/> |
| 0   | Radio Ibiza | [>](https://str48.fluid.stream/RadioIbizaTV/livestream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/uu0DHY5.png"/> |
| 0   | Radio Iglesias Visual Radio | [>](https://59d7d6f47d7fc.streamlock.net/visualradio/visualradio/playlist.m3u8) | <img height="20" src="https://hostux.pics/images/2026/09/11/09_radio_iglesias_visual_radio0c4227f7a483885d.png"/> |
| 0   | Radio Immagine Tv | [>](https://media.velcom.it:8081/RadioImmagineTV/index.fmp4.m3u8) | <img height="20" src="https://i.imgur.com/iQlXRAB.png"/> |
| 0   | Radio Italia Cina Tv | [>](https://585b674743bbb.streamlock.net/9054/9054/playlist.m3u8) | <img height="20" src="https://i.imgur.com/QGkyrO3.png"/> |
| 0   | Radio Juke Box TV | [>](https://5926fc9c7c5b2.streamlock.net/9108/9108/playlist.m3u8) | <img height="20" src="https://hostux.pics/images/2026/09/11/10_radio_juke_box_tvaf2d724a9b16146f.png"/> |
| 0   | Radio Kiss Kiss Italia TV | [>](https://58f12ffd2447a.streamlock.net/KKTV01/livestream/playlist.m3u8) | <img height="20" src="https://hostux.pics/images/2026/09/11/11_radio_kiss_kiss_italia_tv14a58fd92334188a.png"/> |
| 76  | Radio Kiss Kiss Napoli TV | [>](https://58f12ffd2447a.streamlock.net/KKTVNapoli/livestream/playlist.m3u8) | <img height="20" src="https://hostux.pics/images/2026/09/11/12_radio_kiss_kiss_napoli_tv9bfaa8b980862ccb.png"/> |
| 0   | Radio Libertà  | [>](https://router.xdevel.com/video0s975360-67/stream/playlist_dvr.m3u8) | <img height="20" src="https://i.imgur.com/HRvPlf5.png"/> |
| 0   | Radio m2o Tv   | [>](https://4c4b867c89244861ac216426883d1ad0.msvdn.net/live/S62628868/uhdWBlkC1AoO/playlist.m3u8) | <img height="20" src="https://i.imgur.com/wl30UFj.png"/> | m2oTV.it |
| 0   | Radio Monte Kronio Tv (R.M.K.) | [>](https://648026e87a75e.streamlock.net/rmktv/rmktv/playlist.m3u8) | <img height="20" src="https://i.imgur.com/t0I2Shi.jpg"/> |
| 0   | Radio Napoli Emme | [>](http://rtmp.streams.ovh:1935/radionapoliemme/radionapoliemme/playlist.m3u8) | <img height="20" src="https://hostux.pics/images/2026/09/11/13_radio_napoli_emme7a755fab8578a752.png"/> |
| 0   | Radio Norba Tv | [>](https://router.xdevel.com/video0s975885-462/stream/playlist_dvr.m3u8) | <img height="20" src="https://i.imgur.com/qftBPM9.png"/> | RadionorbaTV.it |
| 0   | Radio Number One TV | [>](https://56b50ada2d659.streamlock.net/RN1TV/livestream/playlist.m3u8) | <img height="20" src="https://hostux.pics/images/2026/09/11/14_radio_number_one_tv7003522663a1b412.png"/> |
| 0   | Radio Padova TV | [>](https://58d921499d3d3.streamlock.net/RadioPadova/livestream/playlist.m3u8) | <img height="20" src="https://hostux.pics/images/2026/09/11/15_radio_padova_tv46f0206ee59dba68.png"/> |
| 0   | Radio Piter Pan Tv | [>](https://tvd-piter.fluid.stream/RadioPiterpanTV/livestream/chunklist_w1866496033.m3u8) | <img height="20" src="https://uaznao.com/wp-content/uploads/2023/03/radiopiterpan.png"/> |
| 0   | Radio Punto Zero TV | [>](https://58d921499d3d3.streamlock.net/RPZ/livestream/playlist.m3u8) | <img height="20" src="https://hostux.pics/images/2026/09/11/16_radio_punto_zero_tvb293db9d29587093.png"/> |
| 0   | Radio Radio Tv | [>](https://200912.global.ssl.fastly.net/646b335e2291a2022444bb7c/live_22f84390fe1411ed919df3da85a483cc/rewind-14400.m3u8) | <img height="20" src="https://i.imgur.com/iKuRg2b.png"/> | RadioRadioTV.it |
| 0   | Radio Radiosa Tv | [>](https://stream7.zivoli.it/radiosatv/radiosatv/playlist.m3u8) | <img height="20" src="https://i.imgur.com/8kqyxvz.png"/> |
| 0   | Radio Ritmo 80 TV | [>](https://tvd-rit80.fluid.stream/Ritmo80TV/livestream/playlist.m3u8) | <img height="20" src="https://hostux.pics/images/2026/09/11/17_radio_ritmo_80_tv695eff878745049b.png"/> |
| 0   | Radio Roma | [>](https://585b674743bbb.streamlock.net/9044/9044/playlist.m3u8) | <img height="20" src="https://i.imgur.com/RKvfStm.png"/> |
| 0   | Radio Roma Television | [>](https://5926fc9c7c5b2.streamlock.net/rtfeunawfu/rtfeunawfu/playlist.m3u8) | <img height="20" src="https://i.imgur.com/RKvfStm.png"/> |
| 0   | Radio Studio TV | [>](https://stream10.xdevel.com/video0s978116-2477/stream/playlist.m3u8) | <img height="20" src="https://hostux.pics/images/2026/09/11/18_radio_studio_tv037362682a113768.png"/> |
| 0   | Radio Taormina TV | [>](https://stream2.xdevel.com/video1s3-7/stream/playlist.m3u8) | <img height="20" src="https://hostux.pics/images/2026/09/11/19_radio_taormina_tvd6556d66aa925cb7.png"/> |
| 0   | Radio Televisione Sarda | [>](https://stream.ejatv.com/memfs/dff807e1-b3b2-49f5-92d6-5b178be4eb6d.m3u8) | <img height="20" src="https://hostux.pics/images/2026/09/11/20_radio_televisione_sarda1e0f712e2f44bb50.png"/> |
| 0   | Radio Tivù Azzurra | [>](https://video.azotosolutions.com:9553/radiotivuazzurralive/radiotivuazzurralive/playlist.m3u8) | <img height="20" src="https://hostux.pics/images/2026/09/11/21_radio_tivu_azzurra44ecaf55746f67ba.png"/> |
| 0   | Ran Friul | [>](https://load-balancer.azotosolutions.com/cdnedge34/ranfriul/playlist.m3u8) | <img height="20" src="https://i.imgur.com/Qs5eQPM.png"/> |
| 0   | RDE Tv | [>](https://rst2.saiuzwebnetwork.it:8081/rdetrieste/index.m3u8) | <img height="20" src="https://i.imgur.com/NiwPlrr.png"/> |
| 0   | Reggio Tv | [>](https://cdn10.streamshow.it/cloud-reggiotv/reggiotv/playlist.m3u8) | <img height="20" src="https://i.imgur.com/merrg2C.png"/> |
| 0   | Rei Tv | [>](https://5f22d76e220e1.streamlock.net/reitv/reitv/playlist.m3u8) | <img height="20" src="https://i.imgur.com/YNRWFOo.png"/> |
| 0   | Rete 55 | [>](https://live1.giocabet.tv/stream/6/index.m3u8) | <img height="20" src="https://i.imgur.com/EsZn2cj.png"/> |
| 0   | Rete 7 Tv | [>](https://stream.ets-sistemi.it:2020/hls/rete7-live/rete7-live.m3u8) | <img height="20" src="https://i.imgur.com/lUTxfoh.png"/> |
| 0   | Rete 8 Vga | [>](https://64b16f23efbee.streamlock.net/rete8/rete8/playlist.m3u8) | <img height="20" src="https://i.imgur.com/3wF2AJX.jpg"/> |
| 0   | Rete 8 | [>](https://64b16f23efbee.streamlock.net/rete8/rete8/playlist.m3u8) | <img height="20" src="https://i.imgur.com/bGsjPRh.png"/> |
| 0   | Rete 8 Sport | [>](https://64b16f23efbee.streamlock.net/rete8sport/rete8sport/playlist.m3u8) | <img height="20" src="https://i.imgur.com/uUAjWlF.png"/> |
| 0   | Rete Biella Tv | [>](https://sb.top-ix.org/retebiella/streaming/playlist.m3u8) | <img height="20" src="https://i.imgur.com/e2ryHx7.png"/> |
| 0   | Rete Mia  | [>](https://5db313b643fd8.streamlock.net/rete/rete/playlist.m3u8) | <img height="20" src="https://i.imgur.com/kCJ621Q.png"/> |
| 0   | Rete Oro Tv | [>](https://5926fc9c7c5b2.streamlock.net/9094/9094/playlist.m3u8) | <img height="20" src="https://i.imgur.com/OCxGtwA.png"/> |
| 0   | Rete Sole | [>](https://5926fc9c7c5b2.streamlock.net/9332/9332/playlist.m3u8) | <img height="20" src="https://i.imgur.com/u0ezKgE.png"/> |
| 0   | Rete Tv Italia | [>](https://57068da1deb21.streamlock.net/retetvitalia/retetvitalia/playlist.m3u8) | <img height="20" src="https://i.imgur.com/lXGWoV9.png"/> |
| 0   | Rete Veneta | [>](http://wms.shared.streamshow.it/reteveneta/reteveneta/playlist.m3u8) | <img height="20" src="https://i.imgur.com/cInhQFp.png"/> |
| 0   | Roma Tv 82 | [>](https://streaming.softwarecreation.it/RomaCH71/RomaCH71/playlist.m3u8) | <img height="20" src="https://i.imgur.com/C3UnlFF.png"/> |
| 0   | Rossini Tv | [>](https://stream.rossinitv.it/memfs/3bca4ad7-adfc-4610-ac0e-e826743ddc57.m3u8) | <img height="20" src="https://i.imgur.com/K0Em0nx.jpg"/> |
| 0   | RTC Quarta Rete | [>](https://msh0232.stream.seeweb.it/live/stream00.sdp/playlist.m3u8) | <img height="20" src="https://i.imgur.com/rFGA6qL.png"/> |
| 0   | RTC Telecalabria | [>](https://w1.mediastreaming.it/calabriachannel/livestream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/tTYLcuh.jpg"/> | RTCTelecalabria.it |
| 0   | RTI Calabria | [>](https://stream.ets-sistemi.it:8081/rticalabria/index.m3u8) | <img height="20" src="https://i.imgur.com/hVzEvmo.jpg"/> |
| 0   | RTL 102.5 + Plus | [>](https://streamcdng14-dd782ed59e2a4e86aabf6fc508674b59.msvdn.net/live/S82929343/cAcsSu4Wecc5/chunklist_b5256000.m3u8) | <img height="20" src="https://i.imgur.com/mPqDtCO.png"/> | RTL1025Plus.it |
| 0   | RTM Manduria | [>](https://5f22d76e220e1.streamlock.net/rtm/rtm/playlist.m3u8) | <img height="20" src="https://i.imgur.com/WwzU0EP.png"/> |
| 0   | RTN Napoli | [>](https://rst2.saiuzwebnetwork.it:8081/saiuz-2/index.m3u8) | <img height="20" src="https://hostux.pics/images/2026/09/11/22_rtn_napoli29538077f1c13762.png"/> |
| 0   | Rtp Tv | [>](https://flash2.xdevel.com/rtptv/rtptv/playlist.m3u8) | <img height="20" src="https://i.imgur.com/I1hYI0C.png"/> |
| 0   | RTR99 Tv | [>](https://5e73cf528f404.streamlock.net/RTR99TV/livestream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/mkO95pD.png"/> |
| 0   | Rttr | [>](https://5f204aff97bee.streamlock.net/RTTRlive/livestream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/z7xMArA.png"/> |
| 0   | Rtv 38 Toscana | [>](https://845d8509d2cb4f249dd0b2ae5755b6c2.msvdn.net/rtv38/rtv38_live_main/mainabr/playlist_dvr.m3u8) | <img height="20" src="https://i.imgur.com/xqlhJqK.png"/> |
| 0   | SL 48 Tv | [>](http://media.velcom.it:1935/sl48/sl48/playlist.m3u8) | <img height="20" src="https://i.imgur.com/b58oouu.jpg"/> |
| 0   | ST Europe Channel | [>](https://5f22d76e220e1.streamlock.net/steuropetv/steuropetv/playlist.m3u8) | <img height="20" src="https://i.imgur.com/QpPgSfr.png"/> |
| 0   | Sardegna 1 | [>](https://7e1cc2454f2242afabe05cc0a2f483cd.msvdn.net/live/S30721796/ZS3Xu8mn5f0J/playlist.m3u8) | <img height="20" src="https://i.imgur.com/YNEW2h2.png"/> |
| 0   | Set Tv Cilento  | [>](https://stream1.aswifi.it/settv/live/index.m3u8) | <img height="20" src="https://i.imgur.com/qN5D1jD.png"/> |
| 0   | Sesta Rete | [>](https://stream10.xdevel.com/video0s977089-1792/stream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/0B0S2gI.png"/> |
| 0   | Sicilia 24 Tv | [>](https://5f22d76e220e1.streamlock.net/sicilia24/sicilia24/playlist.m3u8) | <img height="20" src="https://i.imgur.com/GhQX36O.png"/> |
| 0   | Sicilia Tv | [>](https://stream9.xdevel.com/video0s976441-1226/stream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/I5FoThW.png"/> |
| 0   | Sienatv | [>](https://router.xdevel.com/video0s976727-1441/stream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/gcysky4.png"/> |
| 0   | Sophia Tv | [>](https://bild-und-ton.stream/sophiatv-it/smil:sophia-tv-it.smil/playlist.m3u8) | <img height="20" src="https://i.imgur.com/fiLNK3b.jpg"/> |
| 0   | Stiletv | [>](https://proxy.media.convergenze.it/stiletv/streams/oQOFd7JglHjO1631525551097.m3u8) | <img height="20" src="https://i.imgur.com/ZP3cJi7.png"/> |
| 0   | Studio 100 | [>](https://cdn16.streamshow.it/cloud-studio100/studio100/playlist.m3u8) | <img height="20" src="https://i.imgur.com/z84qFXd.png"/> |
| 0   | Super J Tv | [>](https://59d39900ebfb8.streamlock.net/SuperJtv/SuperJtv/playlist.m3u8) | <img height="20" src="https://i.imgur.com/5oy5Nuu.png"/> |
| 0   | Super Six | [>](https://5db313b643fd8.streamlock.net/SUPERSIXLombardia/SUPERSIXLombardia/playlist.m3u8) | <img height="20" src="https://i.imgur.com/kHSuyub.png"/> | SuperSix.it |
| 0   | Supertv | [>](http://wms.shared.streamshow.it:1935/supertv/supertv/live.m3u8) | <img height="20" src="https://i.imgur.com/7gUZcEh.png"/> |
| 0   | T9 | [>](https://streaming.softwarecreation.it/tnove/tnove/playlist.m3u8) | <img height="20" src="https://i.imgur.com/XzL05Py.png"/> |
| 0   | TRC Santeramo | [>](https://stream7.livinlive.it/trc/trc/playlist.m3u8) | <img height="20" src="https://i.imgur.com/VbYdS8P.jpg"/> |
| 13  | TRG Media | [>](https://www.trgmedia.it/hls/livestreamHD.m3u8) | <img height="20" src="https://hostux.pics/images/2026/09/11/30_trg_media50fbce3fd42ecedb.png"/> |
| 0   | TRL Tele Radio Leo | [>](https://5db313b643fd8.streamlock.net/TRL/TRL/playlist.m3u8) | <img height="20" src="https://i.imgur.com/qAagkJT.png"/> |
| 86  | TRSP Tele Radio San Pietro | [>](https://5a1178b42cc03.streamlock.net/trsptv/trsptv/playlist.m3u8) | <img height="20" src="https://hostux.pics/images/2026/09/11/31_trsp_tele_radio_san_pietroe201f062394d1eaa.png"/> |
| 0   | TSD Tv Arezzo(Tele San Domenico) | [>](https://stream.mariatvcdn.com/tsd/7c59373bfdb38201b9215ff86f0ce6af.sdp/playlist.m3u8) | <img height="20" src="https://i.imgur.com/WQ8eQXc.png"/> |
| 85  | TSN Tele Sondrio News | [>](https://189790-castr.akamaized.net/633d685a281cd401ae82c2f7/live_bc04bf70449f11ed80952100db9e5fd9/tracks-v1a1/rewind-3600.m3u8) | <img height="20" src="https://i.imgur.com/24Anl5o.png"/> |
| 0   | TVL (TV Libera Pistoia) | [>](https://oj7lnw79lg82-hls-live.mariatvcdn.it/mariatvcdn/70564e1c6884c007c76f0c128d679eed.sdp/playlist.m3u8) | <img height="20" src="https://i.imgur.com/07geF0L.png"/> |
| 0   | Tcf Tv | [>](https://stream10.xdevel.com/video1s977294-1864/stream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/fiylFs2.jpg"/> |
| 0   | Tci | [>](https://tbn-jw.cdn.vustreams.com/live/tci/live.isml/2b7d53c5-b504-4d26-b25f-a70deb8d0faf.m3u8) | <img height="20" src="https://i.imgur.com/lCZTaKs.jpg"/> |
| 0   | Teatro Tv | [>](https://teatrotv.iostream.it/teatrotv.m3u8) | <img height="20" src="https://i.imgur.com/UsvffQL.png"/> |
| 0   | Tele A | [>](https://lostream.it/hls/telea/video.m3u8) | <img height="20" src="https://i.imgur.com/l7Za9KH.jpg"/> |
| 0   | Tele Abruzzo Tv | [>](http://uk4.streamingpulse.com:1935/TeleabruzzoTV/TeleabruzzoTV/playlist.m3u8) | <img height="20" src="https://i.imgur.com/koB8J4b.jpg"/> |
| 0   | Tele Acras | [>](https://5db313b643fd8.streamlock.net/teleacras/teleacras/playlist.m3u8) | <img height="20" src="https://i.imgur.com/90Lsv8q.png"/> |
| 0   | Tele Arena | [>](https://5e73cf528f404.streamlock.net/TeleArena/TeleArena.stream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/9hsoWMO.png"/> |
| 0   | Tele Bari | [>](https://w1.mediastreaming.it/telebari/livestream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/HYSz4rx.png"/> |
| 0   | Tele Belluno | [>](https://g2qd3exzy7an-hls-live.mariatvcdn.it/livetelebelluno/be0e3154b820953ce1a94a937bb2bb5d.sdp/playlist.m3u8) | <img height="20" src="https://i.imgur.com/YiM2Z7E.png"/> |
| 0   | Tele Boario | [>](https://stream7.xdevel.com/video0s976425-1244/stream/playlist_dvr.m3u8) | <img height="20" src="https://i.imgur.com/LlLD3L6.png"/> |
| 0   | Tele Bruzzano | [>](https://playerssl.telemia.tv/fileadmin/hls/Telebruzzano/telebruzzano_mediachunks.m3u8) | <img height="20" src="https://i.imgur.com/7TWbCDt.jpg"/> |
| 0   | Tele Chiara | [>](http://fms.tvavicenza.it:1935/telechiara/diretta/playlist.m3u8) | <img height="20" src="https://i.imgur.com/Q5XpnXR.png"/> |
| 0   | Tele Club Italia | [>](https://www.theclubfactory.com/streaming/index.m3u8) | <img height="20" src="https://i.imgur.com/WxkOgg0.png"/> |
| 0   | Telecolor | [>](https://1aadf145546f475282c5b4e658c0ac4b.msvdn.net/live/324149/hlbAWtl/playlist.m3u8) | <img height="20" src="https://i.imgur.com/urUG78J.png"/> | TelecolorLombardia.it |
| 11  | Telecolor Sicilia |  [>](https://antennasicilialive.cdn.netrw.it/antennasicilialive/hls/ccr/telecolor/master.m3u8) | <img height="20" src="https://i.imgur.com/rfNg6fw.png"/> |
| 0   | Telecolore Salerno | [>](https://stream10.xdevel.com/video14s975955-1911/stream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/3vBq2g2.png"/> |
| 0   | Tele Cupole | [>](https://load-balancer.azotosolutions.com/cdnedge40/telecupole/playlist.m3u8) | <img height="20" src="https://i.imgur.com/ZmUI9zb.png"/> |
| 0   | Tele Estense | [>](https://5e73cf528f404.streamlock.net/TeleEstense/livestream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/X7i7DWo.png"/> |
| 0   | Tele Foggia | [>](https://59d7d6f47d7fc.streamlock.net/telefoggia/telefoggia/playlist.m3u8) | <img height="20" src="https://i.imgur.com/M7tqBu9.jpg"/> |
| 0   | Tele Friuli | [>](https://5757bf2aa08e42248fb9b9d620f5d900.msvdn.net/live/S11646715/pE3ax0lT0rBd/playlist.m3u8) | <img height="20" src="https://i.imgur.com/AoQxZxD.png"/> |
| 0   | Tele Gela | [>](https://64b16f23efbee.streamlock.net/telegela/telegela/playlist.m3u8) | <img height="20" src="https://i.imgur.com/sjrxbgP.png"/> |
| 183 | Tele Golfo RTG | [>](https://nrvideo1.newradio.it:1936/vmbjrayngd/vmbjrayngd/playlist.m3u8) | <img height="20" src="https://hostux.pics/images/2026/09/11/23_tele_golfo_rtg82613af55dc2f27c.png"/> |
| 15  | Tele Granducato | [>](https://www.granducatotv.eu/tv/granducato/hls/index.flashls.m3u8.php?cid=0&m3u8=.m3u8) | <img height="20" src="https://hostux.pics/images/2026/09/11/24_tele_granducatod50b05fad56debe8.png"/> |
| 0   | Tele Ischia | [>](https://57068da1deb21.streamlock.net/livetv/livetv/playlist.m3u8) | <img height="20" src="https://i.imgur.com/vihHVQn.jpg"/> |
| 0   | Tele Jonio | [>](http://59d7d6f47d7fc.streamlock.net/telejonio/telejonio/playlist.m3u8) | <img height="20" src="https://i.imgur.com/qJeDV8R.png"/> |
| 0   | Tele Lacco Ameno | [>](https://rst2.saiuzwebnetwork.it:8081/laccoamenotv/tracks-v1a1/mono.m3u8) | <img height="20" src="https://hostux.pics/images/2026/09/11/25_tele_lacco_ameno054250ed4a5ba4e2.png"/> |
| 0   | Tele Laser | [>](https://585b674743bbb.streamlock.net/9022/9022/playlist.m3u8) | <img height="20" src="https://hostux.pics/images/2026/09/11/26_tele_lasera82328430bd5c30c.png"/> |
| 0   | Tele Liberta' HD | [>](https://streaming.liberta.it/hls/liberta.m3u8) | <img height="20" src="https://i.imgur.com/XzAB5k7.jpg"/> |
| 0   | Tele Liguria Sud | [>](https://64b16f23efbee.streamlock.net/teleliguriasud/teleliguriasud/playlist.m3u8) | <img height="20" src="https://i.imgur.com/BeLAYJ6.jpg"/> |
| 0   | Tele Mantova | [>](https://5ce9406b73c33.streamlock.net/TeleMantova/livestream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/bkSPcs4.png"/> |
| 0   | Tele Mia | [>](https://playerssl.telemia.tv/fileadmin/hls/TelemiaHD/telemia85_mediachunks.m3u8) | <img height="20" src="https://i.imgur.com/SdXpCwL.png"/> |
| 0   | Tele Mia Extra | [>](https://playerssl.telemia.tv/fileadmin/hls/TelemiaExtra/telemiaextra_mediachunks.m3u8) | <img height="20" src="https://i.imgur.com/upzBG32.png"/> |
| 0   | Tele Mistretta | [>](https://live.mariatvcdn.com/telemistretta/8fbcd205ada81b295ee6c211c3a80dde.sdp/playlist.m3u8) | <img height="20" src="https://i.imgur.com/OJ3zUS0.png"/> |
| 0   | Tele Molise | [>](http://185.202.128.1:1935/Telemolise4K/Telemolise4K/playlist.m3u8) | <img height="20" src="https://i.imgur.com/u5VD0x9.png"/> |
| 0   | Tele Nord Genova | [>](https://64b16f23efbee.streamlock.net/telenord/telenord/playlist.m3u8) | <img height="20" src="https://i.imgur.com/I6yegEK.png"/> |
| 0   | TG Norba 24 | [>](https://live-telenorba.cdn.netrw.it/telenorba/hls/ccr/tgnorba/master.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/1/15/Tg_norba24.png/500px-Tg_norba24.png"/> | TGNorba24.it |
| 12  | TGS Telegiornale di Sicilia | [>](https://stream9.xdevel.com/video1s975436-830/stream/playlist.m3u8) | <img height="20" src="https://hostux.pics/images/2026/09/11/29_tgs_telegiornale_di_sicilia6c915db0091ed7a6.png"/> |
| 0   | Telenorba | [>](https://live-telenorba.cdn.netrw.it/telenorba/hls/ccr/telenorba/master.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/it/thumb/2/28/Telenorba_-_Logo_2014.svg/500px-Telenorba_-_Logo_2014.svg.png"/> | Telenorba.it |
| 0   | Tele Nostra | [>](https://13574-8.b.cdn12.com/hls/f099fa8883.ulive/_c/master.m3u8) | <img height="20" src="https://i.imgur.com/FACahKZ.png"/> |
| 0   | Tele Occidente | [>](https://stream9.xdevel.com/video0s976532-1292/stream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/3aOiWKa.png"/> |
| 0   | Tele Oltre | [>](http://1se1.troydesign.eu/np_teleoltre/_definst_/channel1_np_teleoltre/playlist.m3u8?ext=.m3u8) | <img height="20" src="https://i.imgur.com/PxtJAxs.png"/> |
| 0   | Tele One | [>](https://648026e87a75e.streamlock.net/teleone/teleone/playlist.m3u8) | <img height="20" src="https://i.imgur.com/9trB6mj.png"/> |
| 0   | Tele Pace Trento | [>](https://5a1178b42cc03.streamlock.net/telepacetrento/telepacetrento/playlist.m3u8) | <img height="20" src="https://i.imgur.com/o5sQCpF.png"/> |
| 0   | Tele Pavia | [>](http://wms.shared.streamshow.it:1935/telepavia/telepavia/live.m3u8) | <img height="20" src="https://i.imgur.com/YVodo4T.png"/> |
| 0   | Tele Pegaso | [>](https://flash2.xdevel.com/telepegasocanale812/telepegasocanale812/playlist.m3u8) | <img height="20" src="https://i.imgur.com/FQkM8Vd.png"/> |
| 0   | Tele Piadena  | [>](https://stream3.xdevel.com/video0s975441-151/stream/playlist_dvr.m3u8) | <img height="20" src="https://i.imgur.com/VqaPuQN.png"/> |
| 0   | Tele Pordenone | [>](https://video.wifi4all.it/telepn/telepn.m3u8) | <img height="20" src="https://i.imgur.com/dbYwXwg.png"/> |
| 0   | Tele Quattro Trieste | [>](http://wms.shared.streamshow.it/telequattro/telequattro/playlist.m3u8) | <img height="20" src="https://i.imgur.com/MFxQxve.png"/> |
| 0   | Tele Radio Ercolano | [>](https://rst2.saiuzwebnetwork.it:8081/teleradioercolano/index.m3u8) | <img height="20" src="https://i.imgur.com/YPuoy8N.jpg"/> |			
| 0   | Tele Radio Pace 1 | [>](https://jk3lz2bwlw79-hls-live.mariatvcdn.it/teleradiopace1/efcc8fc46cab26315ce3f5845d76008f.sdp/playlist.m3u8) | <img height="20" src="https://i.imgur.com/ORkkXM8.png"/> |
| 0   | Tele Radio Pace 2 | [>](https://zkpywrbgdbeg-hls-live.mariatvcdn.it/teleradiopace2/254c9b5c52a73a94ef0f6169cbd05dc2.sdp/playlist.m3u8) | <img height="20" src="https://i.imgur.com/U4E3eEr.png"/> |
| 0   | Tele Radio Pace 3 | [>](https://932y4273djv8-hls-live.mariatvcdn.it/teleradiopace3/d2274c22e9ee09eb2eda01ed0496f8f5.sdp/playlist.m3u8) | <img height="20" src="https://i.imgur.com/pTqIxFD.png"/> |
| 0   | Tele Radio Pace 4 | [>](https://j78dpr7nyq5r-hls-live.mariatvcdn.it/teleradiopace4/13d74f2cfe921bfbc262697203d47d8f.sdp/playlist.m3u8) | <img height="20" src="https://i.imgur.com/KPHHsN5.png"/> |
| 0   | Tele Radio Orte | [>](https://flash2.xdevel.com/ortetv/ortetv/index.m3u8) | <img height="20" src="https://i.imgur.com/uX2uxvN.png"/> |
| 0   | Tele Radio Sciacca | [>](https://5db313b643fd8.streamlock.net/teleradiosciaccatv/teleradiosciaccatv/playlist.m3u8) | <img height="20" src="https://i.imgur.com/suhz5mE.png"/> |
| 0   | Tele Ritmo | [>](https://ed04.top-ix.org/avtvlive/teleritmo/streaming/playlist.m3u8) | <img height="20" src="https://hostux.pics/images/2026/09/11/27_tele_ritmo751eb955cbd7dec7.png"/> |
| 0   | Tele Sirio | [>](https://www.telesirio.it/live/stream.m3u8) | <img height="20" src="https://i.imgur.com/mDN6QX1.png"/> |
| 0   | Tele Spazio Messina | [>](https://rtm.cyberspazio.cloud:5443/LiveApp/streams/049229794390395765037801.m3u8) | <img height="20" src="https://i.imgur.com/Io5w6lT.png"/> |
| 0   | Tele Stabia / Gigli TV | [>](https://stream3.aswifi.it/giglitv/live/index.m3u8) | <img height="20" src="https://hostux.pics/images/2026/09/11/28_tele_stabia_gigli_tv41f3f911222a7901.png"/> |
| 0   | Tele Sud Puglia | [>](https://64b16f23efbee.streamlock.net/telesud/telesud/playlist.m3u8) | <img height="20" src="https://i.imgur.com/fqTLtvs.png"/> |
| 0   | Tele Tricolore | [>](https://59d7d6f47d7fc.streamlock.net/rs2/rs2/playlist.m3u8) | <img height="20" src="https://i.imgur.com/A2XouAd.png"/> |
| 0   | Tele Tutto | [>](https://600f07e114306.streamlock.net/TT_TELETUTTO/smil:TT.smil/playlist.m3u8) | <img height="20" src="https://i.imgur.com/sZxMP7g.png"/> |
| 0   | Tele Tutto 2 | [>](https://600f07e114306.streamlock.net/TT2_TELETUTTO/livestream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/mxXbMaw.png"/> |
| 0   | Tele Tutto 24 | [>](https://600f07e114306.streamlock.net/TT24_TELETUTTO/livestream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/weKWQgx.png"/> |
| 0   | Tele Venezia | [>](https://59d7d6f47d7fc.streamlock.net/televenezia/televenezia/playlist.m3u8) | <img height="20" src="https://i.imgur.com/SavGpCE.jpg"/> |
| 0   | Tele Video Agrigento (T.V.A.) | [>](https://59d7d6f47d7fc.streamlock.net/tva/tva/playlist.m3u8) | <img height="20" src="https://i.imgur.com/AaPr63E.png"/> |
| 0   | Tele8 Tv | [>](https://57068da1deb21.streamlock.net/teletv8/teletv8/playlist.m3u8) | <img height="20" src="https://i.imgur.com/dM0HE6O.png"/> |
| 0   | TeleAmbiente | [>](https://5f22d76e220e1.streamlock.net/teleambiente2024/teleambiente2024/playlist.m3u8) | <img height="20" src="https://i.imgur.com/jxZcQhU.png"/> |
| 0   | Telecampione | [>](https://5f22d76e220e1.streamlock.net/telecampione/telecampione/playlist.m3u8) | <img height="20" src="https://i.imgur.com/LhjwmME.png"/> |
| 0   | Telecittà Padova | [>](https://tango.wifi4all.it/telecitta/telecitta.m3u8) | <img height="20" src="https://i.imgur.com/xvVgEaA.jpg"/> |
| 0   | Telecity Lombardia | [>](https://64b16f23efbee.streamlock.net/telecitylombardia/telecitylombardia/playlist.m3u8) | <img height="20" src="https://i.imgur.com/ECvJ3ZD.jpeg"/> |
| 0   | Telecity Piemonte | [>](https://64b16f23efbee.streamlock.net/telecitypiemonte/telecitypiemonte/playlist.m3u8) | <img height="20" src="https://i.imgur.com/CrlzHjv.jpeg"/> |
| 0   | Telecity Valle D'Aosta | [>](https://64b16f23efbee.streamlock.net/telecityvda/telecityvda/playlist.m3u8) | <img height="20" src="https://i.imgur.com/T9EsAOX.jpeg"/> |
| 0   | TeleCostaSmeralda | [>](https://7e1cc2454f2242afabe05cc0a2f483cd.msvdn.net/tcs_live/tcs/tcs/playlist.m3u8) | <img height="20" src="https://i.imgur.com/QLqkbss.png"/> |
| 0   | Telegenova | [>](https://64b16f23efbee.streamlock.net/telegenova/telegenova/playlist.m3u8) | <img height="20" src="https://i.imgur.com/D6HC0So.png"/> |
| 0   | Teleiblea | [>](https://64b16f23efbee.streamlock.net/teleiblea/teleiblea/playlist.m3u8) | <img height="20" src="https://i.imgur.com/n1THygZ.png"/> |
| 0   | Teleitalia 41 | [>](https://streaming.softwarecreation.it/teleitalia/teleitalia/playlist.m3u8) | <img height="20" src="https://i.imgur.com/lTuPSOn.png"/> |
| 0   | Telejato | [>](https://telejato.liberotratto.com/hls/stream.m3u8) | <img height="20" src="https://i.imgur.com/r3Dqzdj.png"/> |
| 0   | Teleleonessa | [>](http://wms.shared.streamshow.it:1935/teleleonessa/teleleonessa/live.m3u8) | <img height="20" src="https://i.imgur.com/jq3etlV.png"/> |
| 0   | TeleMajg | [>](https://59d7d6f47d7fc.streamlock.net/telemajg/telemajg/playlist.m3u8) | <img height="20" src="https://i.imgur.com/9tefonp.jpg"/> |
| 0   | Telenova | [>](https://64b16f23efbee.streamlock.net/telenova/telenova/playlist.m3u8) | <img height="20" src="https://i.imgur.com/x41IkJK.png"/> | Telenova.it |
| 0   | Telerama | [>](https://58d921499d3d3.streamlock.net/TeleRama/livestream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/enfqUlI.jpg"/> |
| 0   | TeleRegione | [>](https://streaming.softwarecreation.it/TR118/TR118/playlist.m3u8) | <img height="20" src="https://i.imgur.com/i5WozUP.png"/> |
| 0   | TeleRegione Color | [>](https://live.antennasudwebtv.it:9443/hls/vodtele.m3u8) | <img height="20" src="https://i.imgur.com/vi5Nf3S.png"/> |
| 0   | TeleRegione Live | [>](https://5f22d76e220e1.streamlock.net/galluralive/galluralive/playlist.m3u8) | <img height="20" src="https://i.imgur.com/DBrt8L3.png"/> |
| 0   | TeleRent 7Gold | [>](https://router.xdevel.com/video0s86-21/stream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/YZadq0M.png"/> | 7Gold.it |
| 0   | Telereporter | [>](https://5f22d76e220e1.streamlock.net/telereporter/telereporter/playlist.m3u8) | <img height="20" src="https://i.imgur.com/WIo6SPc.png"/> |
| 0   | Teleromagna | [>](https://livetr.teleromagna.it/teleromagna/live/playlist.m3u8) | <img height="20" src="https://i.imgur.com/4jWadI8.png"/> |
| 0   | Teleromagna 24 | [>](https://livetr.teleromagna.it/mia/live/playlist.m3u8) | <img height="20" src="https://i.imgur.com/Bpml478.png"/> |
| 0   | TeleRomaDue | [>](https://57068da1deb21.streamlock.net/teletibur/teletibur/playlist.m3u8) | <img height="20" src="https://i.imgur.com/78hA7ma.png"/> |
| 0   | Telesud Trapani | [>](https://64b16f23efbee.streamlock.net/telesudtrapani/telesudtrapani/playlist.m3u8) | <img height="20" src="https://i.imgur.com/tpZvU1P.png"/> |
| 0   | Telesveva | [>](https://dc3.telesveva.com:4433/cmaf/livetv/index.mpd) | <img height="20" src="https://i.imgur.com/SCDETZC.jpeg"/> |
| 0   | Teleuniverso | [>](https://stream.ets-sistemi.it:19360/teleuniverso/teleuniverso.m3u8) | <img height="20" src="https://i.imgur.com/u8E9wBb.png"/> |
| 0   | Televallo Trapani | [>](https://64b16f23efbee.streamlock.net/televallo/televallo/playlist.m3u8) | <img height="20" src="https://i.imgur.com/P6zuiRH.png"/> |
| 0   | TLT Molise | [>](https://5f22d76e220e1.streamlock.net/tltmolise/tltmolise/playlist.m3u8) | <img height="20" src="https://i.imgur.com/wgwD7gh.png"/> |
| 0   | Top Calcio 24 | [>](https://sportitaliaamd.akamaized.net/live/Telelombardia/hls/1CCCD0BCA2F9C979BC0632230F8E31EAEA41562B/index.m3u8) | <img height="20" src="https://i.imgur.com/DnVPKPE.png"/> |
| 0   | Tremedia Tv | [>](https://stream4.xdevel.com/video0s976062-1263/stream/playlist_dvr.m3u8) | <img height="20" src="https://i.imgur.com/dqRV1ff.jpeg"/> |
| 0   | Trentino Tv | [>](https://5e73cf528f404.streamlock.net/TrentinoTV/livestream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/ROKOCR2.png"/> |
| 0   | Tuscia Sabina 2000Tv | [>](http://ts2000tv.streaming.nextware.it:8081/ts2000tv/ts2000tv/chunks.m3u8) | <img height="20" src="https://i.imgur.com/Tq5nEAy.png"/> |
| 0   | Tv 12 | [>](https://59d7d6f47d7fc.streamlock.net/tv12/tv12/playlist.m3u8) | <img height="20" src="https://i.imgur.com/oxv08pJ.png"/> |
| 0   | Tv Campi Flegrei | [>](https://tv.radiosaiuz.com:3836/live/campiflegreilive.m3u8) | <img height="20" src="https://i.imgur.com/9d2K1nX.png"/> |
| 0   | Tv Luna Napoli  | [>](https://diretta.arcapuglia.it:8080/live/teleluna/index.m3u8) | <img height="20" src="https://i.imgur.com/jxhuoyE.png"/> |
| 0   | Tv Prato | [>](https://live.mariatvcdn.com/tvprato/2db0dd5674586686a867ec52c3aa8e06.sdp/mono.m3u8) | <img height="20" src="https://i.imgur.com/zDeVpZd.png"/> |
| 0   | Tv Qui Modena | [>](https://59d7d6f47d7fc.streamlock.net/tvqui/tvqui/playlist.m3u8) | <img height="20" src="https://i.imgur.com/4bOYlfg.png"/> |
| 0   | Tv Uno | [>](http://ftp.tiscali.it/francescovernata/TVUNO/monoscopioTvUNOint-1.wmv) | <img height="20" src="https://i.imgur.com/OtCwYsh.jpg"/> |
| 0   | Tv Yes | [>](https://stream1.aswifi.it/radioyes/live/index.m3u8) | <img height="20" src="https://i.imgur.com/1wsO8U7.png"/> |
| 0   | Tva Vicenza | [>](http://fms.tvavicenza.it:1935/live/diretta_1/playlist.m3u8) | <img height="20" src="https://i.imgur.com/FtFuPCC.png"/> |
| 0   | Tvm Palermo | [>](https://5db313b643fd8.streamlock.net/tvmpa/tvmpa/playlist.m3u8) | <img height="20" src="https://i.imgur.com/uqOdAXB.png"/> |
| 0   | Tvr Xenon | [>](https://cdn107-ita.azotosolutions.com:8443/cdnedge4/smil:live4.smil/playlist.m3u8) | <img height="20" src="https://i.imgur.com/kLzW1Pf.jpg"/> |
| 0   | Tvrs Tv | [>](https://cdn8.streamshow.it/cloud-tvrs/tvrs/playlist.m3u8) | <img height="20" src="https://i.imgur.com/6p7hTmY.jpg"/> |
| 0   | Umbria+ TRT | [>](https://diretta.teleterni.it:8080//show/show.m3u8) | <img height="20" src="https://i.imgur.com/CU6BBgs.png"/> |
| 0   | Umbria Tv  | [>](https://umbriatv.stream.rubidia.it:8083/live/umbriatv/playlist.m3u8) | <img height="20" src="https://i.imgur.com/XKCVEmK.png"/> |
| 0   | Uno Tv  | [>](https://stream1.aswifi.it/unotv/live/index.m3u8) | <img height="20" src="https://i.imgur.com/4PNbqqL.png"/> |
| 0   | Uno4 Tv  | [>](https://cdn.uno4.it/index.m3u8) | <img height="20" src="https://i.imgur.com/wfPPpBA.png"/> |
| 0   | Vera Tv | [>](https://cdn9.streamshow.it/cloud-veratv/veratv/playlist.m3u8) | <img height="20" src="https://i.imgur.com/djMvkvN.png"/> |
| 0   | VB33 | [>](https://live.ipstream.it/vb33/vb33.stream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/ygDuIxU.png"/> |
| 0   | Video Calabria | [>](https://a8a02dd9a49a4fc9810743615c65ab73.msvdn.net/live/S76734991/i6NeNqLYaspb/playlist.m3u8) | <img height="20" src="https://i.imgur.com/Bc2AvIm.png"/> | VideoCalabria.it |
| 0   | Video Mediterraneo | [>](https://bfbe5f347ac4424faf719dda285bc39e.msvdn.net/live/S54897858/4gWO7tTzpK3N/playlist.m3u8) | <img height="20" src="https://i.imgur.com/hJHC3uQ.png"/> |
| 0   | Video Nola | [>](https://videonola.aswifi.it/videonolaabr/live.m3u8) | <img height="20" src="https://i.imgur.com/M5z5UoD.jpg"/> |
| 0   | Video Regione Sicilia | [>](https://57214cb172d84f8cb311b91513952b03.msvdn.net/live/S40896499/ZuaLjACsWIL4/playlist.m3u8) | <img height="20" src="https://i.imgur.com/0szwnR3.png"/> |
| 0   | Video Star Tv Sicilia | [>](https://stream9.xdevel.com/video0s976556-1321/stream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/1ddJVZ7.jpg"/> |
| 0   | Video Touring Tv | [>](https://streamingvideo.auranex.cloud/memfs/70baacad-47c6-41a6-aee0-86530c31e080.m3u8) | <img height="20" src="https://i.imgur.com/E2Feao5.jpg"/> |
| 0   | Videolina | [>](http://livestreaming.videolina.it/live/Videolina/playlist.m3u8) | <img height="20" src="https://i.imgur.com/bnDZJwd.gif"/> |
| 0   | Videonovara | [>](https://ed04.top-ix.org/avtvlive/videonovara/streaming/playlist.m3u8) | <img height="20" src="https://i.imgur.com/NnO7E5I.png"/> |
| 0   | Videotelecarnia | [>](https://rst2.saiuzwebnetwork.it:8081/vtccarnia/index.m3u8) | <img height="20" src="https://i.imgur.com/r4K9JHW.png"/> |
| 0   | Vintage Radio Tv | [>](https://5f22d76e220e1.streamlock.net/vintageradiotv/vintageradiotv/playlist.m3u8) | <img height="20" src="https://i.imgur.com/n3LtBNT.jpg"/> |
| 0   | Vuemme Tv | [>](https://5db313b643fd8.streamlock.net/Vuemme/Vuemme/playlist.m3u8) | <img height="20" src="https://i.imgur.com/x5A0xU6.png"/> |
| 0   | Webcom Tv | [>](https://www.webcomiptv.it/mistserver/passionelotto/index.m3u8) | <img height="20" src="https://i.imgur.com/KLwj2vj.png"/> |
| 0   | WLTV    | [>](https://5db313b643fd8.streamlock.net/WLTV/WLTV/playlist.m3u8) | <img height="20" src="https://i.imgur.com/aL8jKtU.png"/> |
| 0   | Yvii Tv | [>](https://stream.wired-shop.com/hls/yviitv.m3u8) | <img height="20" src="https://i.imgur.com/yP5AvDo.png"/> |
| 0   | Zerouno Tv Music | [>](https://5f22d76e220e1.streamlock.net/zerounotvmusic/zerounotvmusic/playlist.m3u8) | <img height="20" src="https://i.imgur.com/r74lqW8.png"/> |
| 0   | Zerouno Tv News | [>](https://5f22d76e220e1.streamlock.net/01news/01news/playlist.m3u8) | <img height="20" src="https://i.imgur.com/vxRzyjE.png"/> |

<h2>YouTube Live</h2>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 0   | Radio Colonna Tv Ⓨ | [>](https://www.youtube.com/radiocolonna/live) | <img height="20" src="https://i.imgur.com/EcQvDfq.png"/> |
| 519 | TRM h24 Ⓨ     | [>](https://www.youtube.com/user/trmh24/live) | <img height="20" src="https://i.imgur.com/d47CdYU.png"/> | TRMh24.it |
| 59  | Euronews Italian Ⓨ | [>](https://www.youtube.com/user/euronewsit/live) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/9c/Euronews_2022.svg/500px-Euronews_2022.svg.png"/> | EuronewsItalian.fr |

<h2>Twitch Live</h2>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 0   | Teleroma 56 Ⓣ | [>](https://www.twitch.tv/teleroma_56) | <img height="20" src="https://i.imgur.com/wGfpUj8.png"/> |
| 0   | TeleRadioStereo Ⓣ | [>](https://www.twitch.tv/teleradiostereo) | <img height="20" src="https://i.imgur.com/eRNgqnA.png"/> |

<h2>Invalid</h2>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 41  | K2             | [x](https://d1pmpe0hs35ka5.cloudfront.net/v1/master/3722c60a815c199d9c0ef36c5b73da68a62b09d1/cc-39hsskpppgf72/K2_IT.m3u8) | <img height="20" src="https://i.imgur.com/wlLgSiA.png"/> | K2.it |
| 44  | Frisbee        | [x](https://d6m7lubks416z.cloudfront.net/v1/master/3722c60a815c199d9c0ef36c5b73da68a62b09d1/cc-zmbstsedxme9s/Frisbee_IT.m3u8) | <img height="20" src="https://i.imgur.com/9y1zIAe.png"/> | Frisbee.it |
| 63  | GM24 Ⓢ         | [x](https://streaming.softwarecreation.it/GM24/GM24/playlist.m3u8) | <img height="20" src="https://i.imgur.com/UCntSA3.png"/> | GM24.it |
| 61  | BIKE Channel   | [x](https://stream.prod-01.milano.nxmedge.net/argocdn/bikechannel/video.m3u8) | <img height="20" src="https://i.imgur.com/4IzVSQI.png"/> | Bike.it |
| 167 | VH1            | [x](https://content.uplynk.com/channel/36953f5b6546464590d2fcd954bc89cf.m3u8) | <img height="20" src="https://i.imgur.com/5ONlZGS.png"/> | VH1Italia.it |
| 176 | Explorer HD Channel | [x](https://59d7d6f47d7fc.streamlock.net/explorerhdch/explorerhdch/playlist.m3u8) | <img height="20" src="https://i.imgur.com/gFwhIZC.png"/> | ExplorerHDChannel.it |
| 511 | BFC            | [x](https://62becaa5a1e2f.streamlock.net/BFC/BFC/playlist.m3u8) | <img height="20" src="https://i.imgur.com/3OOsLu6.png"/> | BFCForbes.it |
| 0   | Antenna Sud Sport | [x](https://live.antennasudwebtv.it:9443/hls/vodsport.m3u8) | <img height="20" src="https://i.imgur.com/cEyZnhJ.png"/> |
| 0   | Antenna Sud Sport 2 | [x](https://live.antennasudwebtv.it:9443/hls/vodsport2.m3u8) | <img height="20" src="https://i.imgur.com/dl86FW1.png"/> |
| 0   | Apulia Web Tv | [x](https://cp1.server89.com:19360/apuliawebtv/apuliawebtv.m3u8) | <img height="20" src="https://i.imgur.com/AnU4g2J.png"/> |
| 0   | Canale 58 | [x](https://dotfvxkfj90ca.cloudfront.net/live/canale58_aac/master.m3u8) | <img height="20" src="https://i.imgur.com/RlFc74C.png"/> |
| 0   | Canale Uno Tivù Ⓣ | [x](https://www.twitch.tv/canaleunotivu) | <img height="20" src="https://i.imgur.com/hfqNw92.png"/> |
| 0   | Cilento Channel | [x](https://streaming.dimind.it/live/cilentocnn/index.m3u8) | <img height="20" src="https://i.imgur.com/4k9Su8j.png"/> |
| 0   | HUB Tv | [x](https://5c483b9d1019c.streamlock.net/8004/8004/playlist.m3u8) | <img height="20" src="https://i.imgur.com/46GTBEW.png"/> |
| 0   | InSiciliaTv | [x](https://live.elsignage.it/live/insicilia/index.m3u8) | <img height="20" src="https://i.imgur.com/TnVv6WP.png"/> |
| 0   | La Tua Tv | [x](https://wms2.zivoli.it/latuatv/stream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/Nc3I0cS.png"/> |
| 0   | Media Tv | [x](http://live.sloode.com:1935/mediatv/live/playlist.m3u8) | <img height="20" src="https://i.imgur.com/WFiRWO9.png"/> |
| 0   | New Signal Tv Genova | [x](https://5f22d76e220e1.streamlock.net/NewSignalTV/NewSignalTV/playlist.m3u8) | <img height="20" src="https://i.imgur.com/5uGTCJn.png"/> |
| 0   | NSL            | [x](https://streannlivensl.cachefly.net/nsl1/nsl1/playlist.m3u8) | <img height="20" src="https://i.imgur.com/5W6vRaf.png"/> |
| 0   | One Tv Emilia | [x](https://5db313b643fd8.streamlock.net:443/OneTvEmilia/OneTvEmilia/playlist.m3u8) | <img height="20" src="https://i.imgur.com/iAg0Kjl.png"/> |
| 0   | Prima Tivvù Ⓨ | [x](https://www.youtube.com/@PrimaTivvucanale17/live) | <img height="20" src="https://i.imgur.com/oUGS2Nt.png"/> |
| 0   | R+ News Abruzzo | [x](https://5a1178b42cc03.streamlock.net/rnews/rnews/playlist.m3u8) | <img height="20" src="https://i.imgur.com/jKVvT3K.jpg"/> |
| 0   | Radio Tele Tebe | [x](https://5c389faa13be3.streamlock.net:9553/calabriasat/calabriasat/playlist.m3u8) | <img height="20" src="https://i.imgur.com/YirYT4J.png"/> |
| 0   | Reklama Tv | [x](https://5f22d76e220e1.streamlock.net/reklamatv/reklamatv/playlist.m3u8) | <img height="20" src="https://i.imgur.com/hLcDMby.png"/> |
| 0   | Rete Chiara | [x](https://cp1.server89.com:19360/mediamasterpress/mediamasterpress.m3u8) | <img height="20" src="https://i.imgur.com/viL8ZrS.png"/> |
| 0   | Rtc Targato Napoli | [x](https://eu1.servers10.com:8081/8014/index.m3u8) | <img height="20" src="https://i.imgur.com/Jsep7uM.png"/> |
| 0   | SiracusaLive Tv  | [x](https://5db313b643fd8.streamlock.net/SRLIVE_1/SRLIVE_1/playlist.m3u8) | <img height="20" src="https://i.imgur.com/oyPkDnz.jpg"/> |
| 0   | TSE Uno (Tele Scout Europa) | [x](http://stream.mariatvcdn.com/tse/bd5a2cb40637623177295aed22db25f9.sdp/playlist.m3u8) | <img height="20" src="https://i.imgur.com/OA0PRsb.png"/> |
| 0   | Teleblu | [x](https://58d921499d3d3.streamlock.net/Teleblu/livestream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/bZNxSey.png"/> |
| 0   | TeleRomaUno | [x](https://stream9.xdevel.com/video0s976607-1377/stream/playlist_dvr.m3u8) | <img height="20" src="https://i.imgur.com/3t7JWrf.png"/> |
| 0   | Telesardegna | [x](https://dotfvxkfj90ca.cloudfront.net/live/telesardegnalive1_aac/playlist.m3u8) | <img height="20" src="https://i.imgur.com/LC5fKHU.png"/> |
| 0   | Tevere Tv | [x](https://5926fc9c7c5b2.streamlock.net/9098/9098/playlist.m3u8) | <img height="20" src="https://i.imgur.com/ghBX2Hn.png"/> |
| 0   | Tele Argento/Magic Tv | [x](http://163.172.88.73:1935/magic_web/site/playlist.m3u8) | <img height="20" src="https://i.imgur.com/gseTf4W.jpg"/> |
| 0   | Tele Clusone Bergamo | [x](https://media2.streambrothers.com:1936/8068/8068/playlist.m3u8) | <img height="20" src="https://i.imgur.com/dVDY1ng.png"/> |
| 0   | Tele Granda | [x](http://live.sloode.com:1935/telegranda_live/C2AD-0664-DC75-4744/playlist.m3u8) | <img height="20" src="https://i.imgur.com/mdPc8cX.jpg"/> |
| 0   | Tele Lazio Nord | [x](http://tln.srfms.com:1935/TLN/livestream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/gZEojVW.png"/> |
| 0   | Tele Monteneve | [x](http://wms.shared.streamshow.it/telemonteneve3/telemonteneve3/playlist.m3u8) | <img height="20" src="https://i.imgur.com/LJhQApn.jpg"/> |
| 0   | Tele Nord Est | [x](https://59d7d6f47d7fc.streamlock.net/telenord/telenord/playlist.m3u8) | <img height="20" src="https://i.imgur.com/TakoSUX.png"/> |
| 0   | Tele Pace Roma | [x](https://live.mariatvcdn.com/mariatvpoint/d36592901d5429dd7f9ec1e7bbeda8c2.sdp/index.m3u8) | <img height="20" src="https://i.imgur.com/54oi0cg.png"/> |
| 0   | Tele Pace News | [x](https://live.mariatvcdn.com/teleradiopace6/d289fe76f16ad32afec471ea1b941583.sdp/index.m3u8) | <img height="20" src="https://i.imgur.com/AxmgoMT.png"/> |
| 0   | Tele Pace Verona | [x](https://live.mariatvcdn.com/TelepaceVerona/a9027aba28cf4b54d10aedc38b0df192.sdp/index.m3u8) | <img height="20" src="https://i.imgur.com/su2ipkb.png"/> |
| 0   | Tele Prima | [x](http://live.sloode.com:1935/teleprima/live/playlist.m3u8) | <img height="20" src="https://i.imgur.com/WLziQCV.png"/> |
| 0   | Tele Radio Studio 5 | [x](http://mars.az-streamingserver.com:1935/7444/7444/playlist.m3u8) | <img height="20" src="https://i.imgur.com/lPRjSor.jpg"/> |
| 0   | Tris Siracusa | [x](https://5db313b643fd8.streamlock.net/Tris/Tris/playlist.m3u8) | <img height="20" src="https://i.imgur.com/dZgKD3j.jpg"/> |
| 0   | Tsn Lecco | [x](http://59d8c0cee6f3d.streamlock.net/tsn2/tsn2_mobile/playlist.m3u8) | <img height="20" src="https://i.imgur.com/vlyaN3U.jpg"/> |
| 0   | Tua Channel | [x](https://media2021.rtvweb.com/promovideo_web/tuachannel/playlist.m3u8) | <img height="20" src="https://i.imgur.com/BDdQvtS.png"/> |
| 0   | Tv 6 | [x](http://185.202.128.1:1935/Tv6Stream/tv6TV.stream_tlm/playlist.m3u8) | <img height="20" src="https://i.imgur.com/bJ2e604.png"/> |
| 0   | Tv7 Azzurra | [x](https://www.gruppotv7.com:8090/hls/azzurra.m3u8) | <img height="20" src="https://i.imgur.com/xdukioH.png"/> |
| 0   | Tv7 iReporter | [x](https://www.gruppotv7.com:8090/hls/ireporter.m3u8) | <img height="20" src="https://i.imgur.com/37i2B6m.png"/> |
| 0   | Tv7 Triveneta | [x](https://www.gruppotv7.com:8090/hls/triveneta.m3u8) | <img height="20" src="https://i.imgur.com/bYiaO7l.png"/> |
| 0   | TVR Più TeleRegione | [x](https://dacastmmd.mmdlive.lldns.net/dacastmmd/a14a9d0455b34b02842e05e6a4ad0572/playlist.m3u8) | <img height="20" src="https://i.imgur.com/Wzb5qaT.png"/> |
| 0   | Videostar Tv Lombardia | [x](http://dreamsiteradiocpvideo.com:1935/vds/vds/playlist.m3u8) | <img height="20" src="https://i.imgur.com/ecpPFZL.jpg"/> |
| 0   | Well Tv | [x](https://59d7d6f47d7fc.streamlock.net/welltv/welltv/playlist.m3u8) | <img height="20" src="https://i.imgur.com/Kqgz4Na.png"/> |
