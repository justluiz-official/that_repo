<h1>Malta</h1>

<h2>DVB-T</h2>

https://en.wikipedia.org/wiki/List_of_television_stations_in_Malta

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 4   | One            | [>](https://2-fss-1.streamhoster.com/pl_148/201830-1293592-1/playlist.m3u8) | <img height="20" src="https://i.imgur.com/UPlfzFx.png"/> | One.mt |
| 5   | Smash TV       | [>](https://stream.smashmalta.com/live/webplayer/livestream/1.m3u8) | <img height="20" src="https://i.imgur.com/ZKF0fG3.png"/> | SmashTV.mt |

<h2>Invalid</h2>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | TVM Ⓢ Ⓨ        | [>](https://www.youtube.com/channel/UChlf9r1rzhJ_SVM_WCKFL1g/live) | <img height="20" src="https://i.imgur.com/6jaNiUi.png"/> | TVM.mt |
| 2   | TVM 2 Ⓢ        | [x]() | <img height="20" src="https://i.imgur.com/qUZxPez.png"/> |
| 3   | NET TV         | [x]() | <img height="20" src="https://i.imgur.com/DcXBpzx.png"/> | NetTV.mt |
| 6   | F Living       | [x]() | <img height="20" src="https://i.imgur.com/mAbciXA.png"/> | FLivingChannel.mt |
