<h1>Serbia</h1>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1 | RTS 1 | [>](https://webtvstream.bhtelecom.ba/rts1.m3u8) | <img height="20" src="https://i.imgur.com/S1pKHSR.png"/> | RTS1.rs |
| 2 | RTS 2 | [>](https://webtvstream.bhtelecom.ba/rts2.m3u8) | <img height="20" src="https://i.imgur.com/jltAf5h.png"/> | RTS2.rs |
| 3 | RTS 3 | [>](https://webtvstream.bhtelecom.ba/rts_sat.m3u8) | <img height="20" src="https://i.imgur.com/gxuGB4J.png"/> | RTS3.rs |
| 4 | Red TV | [>](https://edge8.pink.rs/redtv/index.m3u8) | <img height="20" src="https://i.imgur.com/cpN7NrL.png"/> | RedTV.rs |
| 5 | Kurir TV | [>](https://static.am.mediaoutcast.com/storage/nQJnjJkO/nQJnjJkO/stream/O68x4o8g/720p/720p.m3u8) | <img height="20" src="https://i.imgur.com/HBPnUD5.png"/> | KurirTV.rs |
| 6 | Informer TV | [>](https://edge-rs-03.maksnet.tv/informertv-secure/web/playlist.m3u8) | <img height="20" src="https://i.imgur.com/9wdEHRf.png"/> | InformerTV.rs |
| 0 | RTS Svet | [>](https://webtvstream.bhtelecom.ba/rts_svet.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/8/8a/Rts-svet.png"/> | RTSSvet.rs |
| 0 | Euronews Serbia | [x](https://d1ei8ofhgfmkac.cloudfront.net/app-19518-1306/ngrp:QoZfNjsg_all/playlist.m3u8) | <img height="20" src="https://i.imgur.com/b24QKcq.png"/> | EuroNewsSerbia.rs |

<h3>Vojvodina</h3>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | RTV 1 | [>](rtmp://212.200.230.50:1935/RTV/rtv1) | <img height="20" src="https://i.imgur.com/CG44YT3.png"/> | RTV1.rs |
| 2   | RTV 2 | [>](rtmp://212.200.230.50:1935/RTV/rtv2) | <img height="20" src="https://i.imgur.com/skpr66t.png"/> | RTV2.rs |
