<h1>Greece</h1>

<h2>Public Channels</h2>


| #  | Channel      | Link                                                                        | Logo                                                     | EPG id        |
|:--:|:-------------|:----------------------------------------------------------------------------|:---------------------------------------------------------|:--------------|
| 1  | ERT 1 Ⓖ      | [>](https://ert-live.siliconweb.com/bpk-tv/ERT1/default/index.mpd)       | <img height="20" src="https://i.imgur.com/WWMe8IY.png"/> | ERT1.gr       |
| 2  | ERT 2 Ⓖ      | [>](https://ert-live.siliconweb.com/bpk-tv/ERT2/default/index.mpd)          | <img height="20" src="https://i.imgur.com/pcusPFl.png"/> | ERT2.gr       |
| 3  | ERT 3 Ⓖ      | [>](https://ert-live.siliconweb.com/bpk-tv/ERT3/default/index.mpd)       | <img height="20" src="https://i.imgur.com/KyhzDRm.png"/> | ERT3.gr       |
| 4  | ERT News     | [>](https://ert-ucdn.broadpeak-aas.com/bpk-tv/ERTNews/default/index.mpd)  | <img height="20" src="https://i.imgur.com/saIGLvr.png"/> | ERTNews.gr    |
| 5  | ERT Cosmos   | [>](https://ert-ucdn.broadpeak-aas.com/bpk-tv/ERTCosmos/default/index.mpd) | <img height="20" src="https://i.imgur.com/KsMTWYw.png"/> | ERTWorld.gr   |
| 6  | ERT Sports 1 | [>](https://ert-ucdn.broadpeak-aas.com/bpk-tv/ERTSports1/default/index.mpd) | <img height="20" src="https://i.imgur.com/gebWmAB.png"/> | ERTSports1.gr |
| 7  | ERT Sports 2 | [>](https://ert-ucdn.broadpeak-aas.com/bpk-tv/ERTSports2/default/index.mpd) | <img height="20" src="https://i.imgur.com/gebWmAB.png"/> | ERTSports2.gr |
| 8  | ERT Sports 3 | [>](https://ert-ucdn.broadpeak-aas.com/bpk-tv/ERTSports3/default/index.mpd) | <img height="20" src="https://i.imgur.com/gebWmAB.png"/> | ERTSports3.gr |
| 9  | ERT Sports 4 | [>](https://ert-ucdn.broadpeak-aas.com/bpk-tv/ERTSports4/default/index.mpd) | <img height="20" src="https://i.imgur.com/gebWmAB.png"/> | ERTSports4.gr |
| 10 | ERT Kids Ⓖ   | [>](https://ert-ucdn.broadpeak-aas.com/bpk-tv/ERTKids/default/index.mpd)    | <img height="20" src="https://i.imgur.com/XkSR66q.png"/> | ERTKids.gr    |
| 11 | Vouli TV     | [>](https://diavlos-cache.cnt.grnet.gr/parltv/webtv-1b.sdp/playlist.m3u8)   | <img height="20" src="https://i.imgur.com/1vqW7lc.png"/> | VouliTV.gr    |
| 12 | RIK Sat      | [>](https://l3.cloudskep.com/cybcsat/abr/playlist.m3u8)                     | <img height="20" src="https://i.imgur.com/9edlXHP.png"/> | RikSatTV.cy   |



<h2>Private National Channels</h2>

| #  | Channel            | Link                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |                                                                    Logo                                                                    |      EPG id      |
|:--:|:-------------------|:------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|:------------------------------------------------------------------------------------------------------------------------------------------:|:----------------:|
| 21 | Mega Channel Ⓖ     | [X](https://c98db5952cb54b358365984178fb898a.msvdn.net/live/S86713049/gonOwuUacAxM/playlist.m3u8)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |                                          <img height="20" src="https://i.imgur.com/TjLy6KT.png"/>                                          |   MEGATVHD.gr    |#
| 22 | Mega News          | [>](https://c98db5952cb54b358365984178fb898a.msvdn.net/live/S99841657/NU0xOarAMJ5X/playlist.m3u8)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |                                          <img height="20" src="https://i.imgur.com/Z3k7iA0.png"/>                                          |  MegaChannel.gr  |
| 23 | ANT1               | [>](https://mcdn.antennaplus.gr/live/media0/Ant1/HLS/Ant1.m3u8)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |                                          <img height="20" src="https://i.imgur.com/xDdVa9U.png"/>                                          |     ANT1.gr      |
| 24 | Star               | [>](https://livestar.siliconweb.com/starvod/star4/star4.m3u8)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |                                          <img height="20" src="https://i.imgur.com/Hp0stVQ.png"/>                                          |  StarChannel.gr  |
| 25 | Star International | [>](https://livestar.siliconweb.com/starvod/star_int/star_int.m3u8)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |                                          <img height="20" src="https://i.imgur.com/Hp0stVQ.png"/>                                          |  StarChannel.gr  |
| 26 | AlphaTV            | [>](https://alphatvlive2.siliconweb.com/alphatvlive/live_abr/playlist.m3u8)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |                                          <img height="20" src="https://i.imgur.com/bAVGX0l.png"/>                                          |    AlphaTV.gr    |
| 27 | Skai TV            | [>](http://skai-live.siliconweb.com/media/cambria4/index.m3u8)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |                                          <img height="20" src="https://i.imgur.com/TSg7B8X.png"/>                                          |    SkaiTV.gr     |
| 28 | Open TV            | [>](https://liveopen.siliconweb.com/openTvLive/liveopen/playlist.m3u8)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |                                          <img height="20" src="https://i.imgur.com/HzBmvPT.png"/>                                          |    OpenTV.gr     |
| 29 | MAK TV             | [>](https://mcdn.antennaplus.gr/live/media0/MAK/HLS/MAK.m3u8)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |                                          <img height="20" src="https://i.imgur.com/90iDHbQ.png"/>                                          |     MakTV.gr     |
| 30 | Euronews Greek     | [>](https://www.youtube.com/euronewsGreek/live) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/4/46/Euronews_2016_logo.svg/500px-Euronews_2016_logo.svg.png"/> | EuronewsGreek.fr |


<h2>Athens Attica Regional Channels</h2>

| #  | Channel         | Link                                                                                                                          | Logo                                                     | EPG id            |
|:--:|:----------------|:------------------------------------------------------------------------------------------------------------------------------|:---------------------------------------------------------|:------------------|
| 31 | Action24        | [>](https://actionlive.siliconweb.com/actionabr/actiontv/playlist.m3u8)                                                       | <img height="20" src="https://i.imgur.com/Zi1YohT.png"/> | Action24TV.gr     |
| 32 | Alert           | [>](https://itv.streams.ovh/ALEERT/ALEERT/playlist.m3u8)                                                                      | <img height="20" src="https://i.imgur.com/xqa87lG.png"/> | alert.gr          |
| 34 | Blue Sky        | [>](https://www.youtube.com/channel/UCBuEruzW_f-Qpj_sABmuYSg/live)                                                        | <img height="20" src="https://i.imgur.com/rzuQslM.png"/> | BlueSky.gr        |
| 35 | High TV         | [>](https://live.streams.ovh/hightv/hightv/playlist.m3u8)                                                                     | <img height="20" src="https://i.imgur.com/wHzCGry.png"/> | hightv.gr         |
| 36 | Kontra          | [>](https://kontralive.siliconweb.com/live/kontratv/playlist.m3u8)                                                            | <img height="20" src="https://i.imgur.com/ROZ9VfV.png"/> | KontraChannel.gr  |
| 37 | Mad Ⓨ           | [>](https://www.youtube.com/c/madtvgreece/live)                                                                                                                         | <img height="20" src="https://i.imgur.com/OTTxxGe.png"/> | Mad.gr            |
| 38 | Naftemporiki TV | [>](https://telmaco.ascdn.broadpeak.io/nafteboriki/default/index.m3u8)                                                        | <img height="20" src="https://i.imgur.com/9OFdMud.png"/> | NaftemporikiTV.gr |
| 39 | One Channel     | [>](https://onechannel.siliconweb.com/one/stream/chunks_dvr.m3u8)                                                             | <img height="20" src="https://i.imgur.com/GwKaHbM.png"/> | OneChannel.gr     |
| 40 | Rise            | [x](http://ovh-edge-h.evrideo.com:8080/23e234f2-aec8-4804-b694-4cdd71d2d48d_MONITORING_HLS/video_240p_WEBRTC_MONITORING.m3u8) | <img height="20" src="https://i.imgur.com/B6ZtqJ8.png"/> | risetv.gr         |
| 41 | Smile           | [x](https://s1.cystream.net/live/smile/playlist.m3u8)                                                                         | <img height="20" src="https://i.imgur.com/Ax6K20a.png"/> | tvsmile.gr        |


<h2>Thessaloniki and Central Macedonia Channels</h2>

| #  | Channel | Link                                                                        | Logo                                                      | EPG id       |
|:--:|:--------|:----------------------------------------------------------------------------|:----------------------------------------------------------|:-------------|
| 51 | 4E      | [>](http://eu2.tv4e.gr:1935/live/myStream.sdp/playlist.m3u8)                | <img height="20" src="https://i.imgur.com/Ed085oJ.png"/>  | 4E.gr        |
| 52 | DION    | [>](https://www.youtube.com/@diontileorash/live)                             | <img height="20" src="https://i.imgur.com/13MverN.png"/>  | DionTV.gr    |
| 53 | Egnatia | [>](https://video.streams.ovh:1936/egnatiatv/egnatiatv/index.m3u)           | <img height="20" src="https://i.imgur.com/zuyYIca.png"/>  | egnatiatv.gr |
| 54 | Euro    | [>](https://live20.bozztv.com/akamaissh101/ssh101/eurotvlive/playlist.m3u8) | <img height="20" src="https://i.imgur.com/mHCk05E.png"/>  | eurotv.gr    |
| 55 | Gnomi   | [>](https://live.streams.ovh:8081/gnomitv/index.m3u8)                       | <img height="20" src="https://i.imgur.com/mHCk05E.png"/>  | gnomitv.gr   |
| 55 | Pella   | [>](https://video.streams.ovh:1936/pellatv/pellatv/playlist.m3u8)           | <img height="20" src="https://i.imgur.com/pwUkkGL.jpeg"/> | pellatv.gr   |
| 55 | Pontos  | [>](https://www.youtube.com/@PontosTV/live)                             | <img height="20" src="https://i.imgur.com/sbTxP6o.png"/>  | pontostv.gr  |
| 56 | TV 100  | [>](https://panel.gwebstream.eu:19360/tv100skg/tv100skg.m3u8)               | <img height="20" src="https://i.imgur.com/9rtf8OR.png"/>  | TV100.gr     |
| 57 | Vergina | [>](https://verginanews.gr:8443/hls_live/stream1.m3u8)                      | <img height="20" src="https://i.imgur.com/cpF6wvR.png"/>  | verginatv.gr |


<h2>Peloponnese Channels</h2>

| #  | Channel        | Link                                                                         | Logo                                                     | EPG id         |
|:--:|:---------------|:-----------------------------------------------------------------------------|:---------------------------------------------------------|:---------------|
| 61 | Best TV        | [>](https://besttv.siliconweb.com/bestTV/live_abr/playlist.m3u8)             | <img height="20" src="https://i.imgur.com/VA13E3w.png"/> | besttv.gr      |
| 62 | Hlektra        | [>](https://live20.bozztv.com/giatv/giatv-hlektratv/hlektratv/playlist.m3u8) | <img height="20" src="https://i.imgur.com/LbogUPS.png">  | hlektra.gr     |
| 63 | Ionian Channel | [>](https://stream.ioniantv.gr/ionian/live_abr/playlist.m3u8)                | <img height="20" src="https://i.imgur.com/ADVYeQd.png"/> | ioniantv.gr    |
| 64 | Lepanto        | [>](https://fr.crystalweb.net:1936/lepantotv/lepantotv/playlist.m3u8)        | <img height="20" src="https://i.imgur.com/h6Tqe0k.png">  | lepantortv.gr  |
| 65 | Lychnos        | [>](https://thor.mental-media.gr:19360/imp/imp.m3u8)                         | <img height="20" src="hhttps://i.imgur.com/JYSlBfY.png"> | lychnostv.gr   |
| 66 | Mesogeios TV   | [>](https://rtmp.win:3793/live/mesogeiostvlive.m3u8)                         | <img height="20" src="https://i.imgur.com/tr0Lf9K.png"/> | mesogeiostv.gr |
| 67 | ORT            | [x](https://fr.crystalweb.net:1936/ort/ort/playlist.m3u8)                    | <img height="20" src="https://i.imgur.com/ytV3lbP.png"/> | ort.gr         |
| 68 | PLP            | [x](https://www.hellasnet.tv/rest2.live.hn/w2r.plp/playlist.m3u8)            | <img height="20" src="https://i.imgur.com/2PTEChx.png">  | plptv.gr       |


<h2>Eastern Sterea, Fokida, Evoea Channels</h2>

| #  | Channel             | Link                                                                                       |                           Logo                            |     EPG id     |
|:--:|:--------------------|--------------------------------------------------------------------------------------------|:---------------------------------------------------------:|:--------------:|
| 71 | Epsilon             | [>](https://neon.streams.gr:8081/epsilontv/index.m3u8)                                     | <img height="20" src="https://i.imgur.com/vUQSDvZ.png"/>  |   epsilon.gr   |
| 73 | 91NRG               | [>](http://tv.nrg91.gr:1935/onweb/live/master.m3u8)                                        |  <img height="20" src="https://i.imgur.com/g1pCRRG.png">  |    nrg91.gr    |


<h2>Thessalia Channels</h2>

| #  | Channel   | Link                                                          |                           Logo                           | EPG id         |
|:--:|:----------|---------------------------------------------------------------|:--------------------------------------------------------:|:---------------|
| 81 | Astra     | [>](https://server.gointernet.gr/live/livestream.m3u8) | <img height="20" src="https://i.imgur.com/oYRPfZm.png"/> | astratv.gr     |
| 82 | Thessalia | [>](https://www.youtube.com/c/thessaliatv1/live)   | <img height="20" src="https://i.imgur.com/KXz67LY.png"/> | thessaliatv.gr |
| 83 | TRT       | [>](https://av.hellasnet.tv/rst/trt/index.m3u8)               | <img height="20" src="https://i.imgur.com/g0jPOcC.png"/> | trttv.gr       |


<h2>Western Greece Channels</h2>

| #  | Channel     | Link                                                                      | Logo                                                       | EPG id        |
|:--:|:------------|---------------------------------------------------------------------------|:-----------------------------------------------------------|:--------------|
| 91 | Acheloos    | [>](https://acheloostv.streamings.gr/live/stream/index.m3u8)              | <img height="20" src="https://i.imgur.com/5SVMxcu.png" />  | acheloostv.gr |
| 92 | ART TV      | [>](https://rtmp.win:3696/live/arttvgrlive.m3u8)                          | <img height="20" src="https://i.imgur.com/LyCqQvx.png" />  | arttv.gr      |
| 93 | Corfu       | [>](https://itv.streams.ovh:1936/corfuchannel/corfuchannel/playlist.m3u8) | <img height="20" src="https://i.imgur.com/dCMqo8w.jpeg" /> | corfutv.gr    |
| 94 | Epirus TV 1 | [>](https://rtmp.win:3929/live/epiruslive.m3u8)                           | <img height="20" src="https://i.imgur.com/QB3aSl1.png" />  | epirustv1.gr  |
| 95 | Start       | [>](https://live.cast-control.eu/StartMedia/StartMedia/playlist.m3u8)     | <img height="20" src="https://i.imgur.com/nrEtmBN.png" />  | starttv.gr    |


<h2>Thrace and Eastern Macedonia Channels</h2>

|  #  | Channel       | Link                                                                      | Logo                                                     | EPG id         |
|:---:|:--------------|---------------------------------------------------------------------------|:---------------------------------------------------------|:---------------|
| 101 | Center TV     | [>](https://eu1.streams.gr:8081/centertv/index.m3u8)                      | <img height="20" src="https://i.imgur.com/52JW71Q.png"/> | CenterTV.gr    |
| 102 | Delta Evros   | [>](http://81.171.10.42:1935/liveD/DStream.sdp/chunklist_w819085920.m3u8) | <img height="20" src="https://i.imgur.com/PDfSkRF.png"/> | DeltaTV.gr     |
| 103 | Thraki Net TV | [>](https://cdn.onestreaming.com/thrakinettv/thrakinettv/playlist.m3u8)   | <img height="20" src="https://i.imgur.com/DV0I0ed.png"/> | ThrakiNetTV.gr |




<h2>Crete</h2>

|  #  | Channel   | Link                                                                  | Logo                                                       | EPG id       |
|:---:|:----------|:----------------------------------------------------------------------|:-----------------------------------------------------------|:-------------|
| 111 | Creta     | [>](http://live.streams.ovh:1935/tvcreta/tvcreta/playlist.m3u8)       | <img height="20" src="https://i.imgur.com/x0qK8IE.png"/>   | CretaTV.gr   |
| 112 | Kriti 1   | [>](https://livetv.streams.ovh:8081/kriti/index.m3u8)                 | <img height="20" src="https://i.imgur.com/C1ucQeC.png"/>   | Kriti1Tv.gr  |
| 113 | Kriti TV  | [>](https://cretetvlive.siliconweb.com/cretetv/liveabr/playlist.m3u8) | <img height="20" src="https://i.imgur.com/eLhYMmc.png"/>   | KritiTv.gr   |
| 114 | NEA       | [>](https://live.neatv.gr:8888/hls/neatv_high/index.m3u8)             | <img height="20" src="https://i.imgur.com/nvNW8G7.png"/>   | NeaTV.gr     |



<h2>Aegean Channels</h2>

|  #  | Channel    | Link                                                                  | Logo                                                     | EPG id      |
|:---:|:-----------|-----------------------------------------------------------------------|:---------------------------------------------------------|:------------|
| 121 | Samiaki TV | [>](http://live.cast-control.eu:1935/samiaki/samiaki/playlist.m3u8)   | <img height="20" src="https://i.imgur.com/aV5QoNG.png"/> | CenterTV.gr |
| 102 | Syros TV1  | [>](https://eco.streams.ovh:1936/syrostv1/syrostv1/playlist.m3u8)     | <img height="20" src="https://i.imgur.com/duXHyvN.png"/> | SyrosTV1.gr |
