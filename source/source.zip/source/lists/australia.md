<h1>Australia</h1>

https://www.freeview.com.au

| #   | Channel         | Link  | Logo | EPG id |
|:---:|:---------------:|:-----:|:----:|:------:|
| 5   | 10 HD           | [>](https://i.mjh.nz/.r/10-nsw.m3u8) | <img height="20" src="https://i.imgur.com/ZjKvXPn.png"/> | 10Sydney.au |
| 1   | ABC             | [>](https://c.mjh.nz/abc-nsw.m3u8) | <img height="20" src="https://i.imgur.com/5CVl5EF.png"/> | ABCTV.au |
| 5   | SBS Ⓖ           | [>](https://i.mjh.nz/.r/sbs-sbst.m3u8) | <img height="20" src="https://i.imgur.com/GBl1ynA.png"/> | SBSTV.au |
| 5   | Seven           | [>](https://i.mjh.nz/.r/seven-syd.m3u8) | <img height="20" src="https://i.imgur.com/6zwKJaa.png"/> | SevenNetwork.au |
| 5   | Nine            | [>](https://i.mjh.nz/.r/channel-9-nsw.m3u8) | <img height="20" src="https://i.imgur.com/SMXwfr5.png"/> | NineNetwork.au |
| 5   | 10 Peach        | [>](https://i.mjh.nz/.r/10peach-nsw.m3u8) | <img height="20" src="https://i.imgur.com/NlZLut8.png"/> | 10Peach.au |
| 5   | 10 Bold         | [>](https://dce3793146fef017.mediapackage.us-west-2.amazonaws.com/out/v1/55cdf73af7894775ba6de8f57482b66a/CMAF_HLS/index.m3u8) | <img height="20" src="https://i.imgur.com/2cq3fY1.png"/> | 10Bold.au |
| 5   | 10 Shake        | [>](https://i.mjh.nz/.r/10shake-nsw.m3u8) | <img height="20" src="https://i.imgur.com/OXtIkOn.png"/> | 10Shake.au |
| 5   | TVSN            | [>](https://tvsnhlslivetest.akamaized.net/hls/live/2034711/EXPO-MSL4/master.m3u8) | <img height="20" src="https://i.imgur.com/p3QCBOo.png"/> | TVSN.au |
| 5   | Spree TV        | [x]() | <img height="20" src="https://i.imgur.com/RyupyDF.png"/> | SpreeTV.au |
| 3   | ABC Kids        | [>](https://c.mjh.nz/abc-kids.m3u8) | <img height="20" src="https://i.imgur.com/GWDRR1t.png"/> | ABCKids.au |
| 4   | ABC Me          | [>](https://c.mjh.nz/abc-me.m3u8) | <img height="20" src="https://i.imgur.com/gBh54wY.png"/> | ABCMe.au |
| 5   | ABC News        | [>](https://c.mjh.nz/abc-news.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/en/thumb/d/df/ABC_News_Channel.svg/500px-ABC_News_Channel.svg.png"/> | ABCNews.au |
| 8   | M4TV      | [>](https://5a32c05065c79.streamlock.net/live/stream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/HZohlNk.png"/> | M4TV.au |
| 5   | SBS Viceland Ⓖ  | [>](https://i.mjh.nz/.r/sbs-2syd.m3u8) | <img height="20" src="https://i.imgur.com/WMKCkD0.png"/> | SBSViceland.au |
| 5   | SBS World Movies Ⓖ | [>](https://i.mjh.nz/.r/sbs-4syd.m3u8) | <img height="20" src="https://i.imgur.com/V6hhtCx.png"/> | SBSWorldMovies.au |
| 5   | SBS Food Ⓖ      | [>](https://i.mjh.nz/.r/sbs-3syd.m3u8) | <img height="20" src="https://i.imgur.com/qN9p4h0.png"/> | SBSFood.au |
| 5   | NITV Ⓖ          | [>](https://i.mjh.nz/.r/sbs-5nsw.m3u8) | <img height="20" src="https://i.imgur.com/YR7sXaN.png"/> | NITV.au |
| 5   | 7two            | [>](https://i.mjh.nz/.r/7two-syd.m3u8) | <img height="20" src="https://i.imgur.com/6pyIg02.png"/> | 7two.au |
| 5   | 7mate           | [>](https://i.mjh.nz/.r/7mate-syd.m3u8) | <img height="20" src="https://i.imgur.com/zpr12HP.png"/> | 7mate.au |
| 5   | 7flix           | [>](https://i.mjh.nz/.r/7flix-syd.m3u8) | <img height="20" src="https://i.imgur.com/6iIYCyC.png"/> | 7flix.au |
| 5   | Racing.com      | [>](https://racingvic-i.akamaized.net/hls/live/598695/racingvic/1500.m3u8) | <img height="20" src="https://i.imgur.com/pma0OCf.png"/> | Racingcom.au |
| 5   | 9Gem Ⓖ          | [>](https://i.mjh.nz/.r/gem-nsw.m3u8) | <img height="20" src="https://i.imgur.com/sWmE1kq.png"/> | 9Gem.au |
| 5   | 9Go! Ⓖ | [>](https://i.mjh.nz/.r/go-nsw.m3u8) | <img height="20" src="https://i.imgur.com/1CFGu5O.png"/> | 9Go.au |
| 5   | 9Life Ⓖ | [>](https://i.mjh.nz/.r/life-nsw.m3u8) | <img height="20" src="https://i.imgur.com/ZCUiqlL.png"/> | 9Life.au |
| 5   | 9Rush Ⓖ | [>](https://i.mjh.nz/.r/rush-nsw.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/en/c/c2/Logo_of_9RUSH.png"/> | 9Rush.au |
| 5   | C31 Melbourne   | [>](https://d1k6kax80wecy5.cloudfront.net/RLnAKY/index.m3u8) | <img height="20" src="https://i.imgur.com/dXwkFei.png"/> | C31Melbourne.au |
